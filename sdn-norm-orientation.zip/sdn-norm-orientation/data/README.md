# Data

The analyses use the openly available dataset published with

> Jin, R., Wang, X., Nguyen, M. H., La, V. P., Le, T. T., & Vuong, Q. H. (2023). A dataset of Chinese
> drivers' driving behaviors and socio-cultural factors related to driving. *Data in Brief, 49*, 109337.
> https://doi.org/10.1016/j.dib.2023.109337

hosted on the Open Science Framework at https://osf.io/stcj2/
(DOI: [10.17605/OSF.IO/STCJ2](https://doi.org/10.17605/OSF.IO/STCJ2)).

The data are not redistributed here. To reproduce the results:

1. Download the CSV file from https://osf.io/stcj2/.
2. Save it in this folder as `Agressive_Driving_Data.csv` (the spelling used by the source).

The file analysed in the paper has SHA-256 checksum

```
c9385e89d8b8808eced589856ac450f3720bb60ff63446e0b9a9624f86d775c6
```

`sdn/data.py` checks this on loading. If your download differs only in encoding or line endings,
a warning is issued and the loader then confirms that the content matches the published codebook:
1,039 respondents × 37 variables, no missing item responses, items coded 1–5, and licence-tenure
(A5) counts of 185 / 408 / 257 / 125 / 64.

## Variables used

| Variable | Content | Coding |
|---|---|---|
| B1–B7 | Safe Behaviour items | 1 = strongly disagree … 5 = strongly agree |
| C1–C9 | Peer Influence items | as above |
| D1–D12 | Parental Influence items | as above |
| A3, A4 | Driving confidence, consequence concern (covariates) | 1–5 |
| A5 | Licence tenure | 1 = <1 yr, 2 = 1–3 yr, 3 = 3–5 yr, 4 = 5–10 yr, 5 = >10 yr |
| E1 | Gender | 1 = male, 2 = female |
| E2 | Education | 1 = middle school or below … 5 = doctoral |
| E3 | Monthly income (RMB) | 1 = <3,000 … 5 = >30,000 |
| E4 | Age group | 1 = 18–25, 2 = 25–30, 3 = 30–40, 4 = 40–50, 5 = 50+ |
