"""Run the full analysis pipeline in order, then check the results against the manuscript.

Usage:  python run_all.py            (all steps, ~20-30 minutes on two cores)
        python run_all.py --skip-resampling   (reuse results/07_resampling.json if present)
"""
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STEPS = sorted((ROOT / "analysis").glob("[0-9][0-9]_*.py"))

if __name__ == "__main__":
    skip = "--skip-resampling" in sys.argv
    t0 = time.time()
    for script in STEPS:
        if skip and script.name.startswith("07_") and (ROOT / "results" / "07_resampling.json").exists():
            print(f"\n=== {script.name} (skipped; using existing results) ===")
            continue
        print(f"\n=== {script.name} ===", flush=True)
        t = time.time()
        subprocess.run([sys.executable, str(script)], check=True, cwd=ROOT)
        print(f"--- {script.name} finished in {time.time() - t:.0f} s", flush=True)
    print(f"\nAll analyses finished in {(time.time() - t0) / 60:.1f} min. Verifying against the manuscript:\n")
    sys.exit(subprocess.run([sys.executable, str(ROOT / "verify.py")], cwd=ROOT).returncode)
