"""Reliability, dimensionality, discriminant validity (Table 3); one- vs three-factor CFA (Table 4);
polychoric robustness check (Section 3.4); per-experience-group one-factor fit (Figure 2B, Section 4.10)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
from scipy import stats

from sdn.data import load, save_json, ITEMS, B, C, D, EXPERIENCE_LABELS
from sdn.cfa import fit_cfa
from sdn.stats_utils import cronbach_alpha, pca_eigen, ave_first_component, htmt, polychoric

df = load()
X = df[ITEMS].values.astype(float)
N = len(X)
subscales = {"B": B, "C": C, "D": D}
idx = {k: [ITEMS.index(i) for i in v] for k, v in subscales.items()}
comp = {k: df[v].mean(axis=1).values for k, v in subscales.items()}

# ---------------------------------------------------------------- Table 3
R = np.corrcoef(X.T)
r_sub = {f"{a}-{b}": float(np.corrcoef(comp[a], comp[b])[0, 1]) for a, b in [("B", "C"), ("B", "D"), ("C", "D")]}
table3 = {}
for k, items in list(subscales.items()) + [("All", ITEMS)]:
    ev = pca_eigen(df[items].values)
    row = dict(n_items=len(items), alpha=cronbach_alpha(df[items].values),
               pc1_pct=100 * ev[0] / len(items), pc1_pc2=ev[0] / ev[1], eig1=ev[0], eig2=ev[1])
    if k != "All":
        row["sqrt_ave"] = float(np.sqrt(ave_first_component(df[items].values)))
        row["max_r_other"] = max(v for pair, v in r_sub.items() if k in pair)
        row["fornell_larcker_violated"] = bool(row["sqrt_ave"] < row["max_r_other"])
    table3[k] = row
htmt_vals = {f"{a}-{b}": float(htmt(R, idx[a], idx[b])) for a, b in [("B", "C"), ("B", "D"), ("C", "D")]}

# ---------------------------------------------------------------- Table 4
S = np.cov(X.T)
one = fit_cfa(S, N, [0] * 28, 1)
blocks = [0] * 7 + [1] * 9 + [2] * 12
three = fit_cfa(S, N, blocks, 3)
dchi = one["chi2"] - three["chi2"]
ddf = one["df"] - three["df"]
phi = three["phi"]


def summ(r):
    return {k: r[k] for k in ["chi2", "df", "chi2_df", "cfi", "tli", "rmsea", "srmr", "aic", "bic"]}


table4 = dict(
    one_factor=dict(**summ(one), loadings_min=one["std_loadings"].min(),
                    loadings_max=one["std_loadings"].max(), loadings_mean=one["std_loadings"].mean(),
                    std_loadings=dict(zip(ITEMS, one["std_loadings"]))),
    three_factor=dict(**summ(three), phi={"B-C": phi[0, 1], "B-D": phi[0, 2], "C-D": phi[1, 2]}),
    lr_test=dict(dchi2=dchi, ddf=ddf, p=float(stats.chi2.sf(dchi, ddf))),
)

# ---------------------------------------------------------------- per-group one-factor fit
per_group = {}
for g, lab in EXPERIENCE_LABELS.items():
    Xg = X[df.A5.values == g]
    r = fit_cfa(np.cov(Xg.T), len(Xg), [0] * 28, 1)
    per_group[lab] = dict(n=len(Xg), **summ(r))

# ---------------------------------------------------------------- polychoric eigenvalues
Xz = df[ITEMS].values.astype(int) - 1
Rp = np.eye(28)
for i in range(28):
    for j in range(i + 1, 28):
        Rp[i, j] = Rp[j, i] = polychoric(Xz[:, i], Xz[:, j])
evp = np.sort(np.linalg.eigvalsh(Rp))[::-1]

out = dict(table3=table3, subscale_r=r_sub, shared_variance_pct=[100 * min(r_sub.values()) ** 2,
                                                                  100 * max(r_sub.values()) ** 2],
           htmt=htmt_vals, table4=table4, per_group_one_factor=per_group,
           polychoric_eigen=evp[:3], polychoric_ratio=evp[0] / evp[1])
save_json("02_structure_cfa", out)

print("Table 3")
for k, r in table3.items():
    extra = f" sqrtAVE {r['sqrt_ave']:.3f} maxr {r['max_r_other']:.3f}" if "sqrt_ave" in r else ""
    print(f"  {k:4s} alpha {r['alpha']:.3f} PC1 {r['pc1_pct']:.1f}% ratio {r['pc1_pc2']:.2f}{extra}")
print("  subscale r:", {k: round(v, 3) for k, v in r_sub.items()}, "HTMT:", {k: round(v, 3) for k, v in htmt_vals.items()})
print("Table 4")
for k in ["one_factor", "three_factor"]:
    r = table4[k]
    print(f"  {k:12s} chi2 {r['chi2']:.1f} df {r['df']} chi2/df {r['chi2_df']:.2f} CFI {r['cfi']:.3f} "
          f"RMSEA {r['rmsea']:.3f} AIC {r['aic']:.1f} BIC {r['bic']:.1f}")
print(f"  loadings {one['std_loadings'].min():.3f}-{one['std_loadings'].max():.3f} M {one['std_loadings'].mean():.3f};"
      f" phi {phi[0, 1]:.3f} {phi[0, 2]:.3f} {phi[1, 2]:.3f}; dchi2({ddf}) = {dchi:.1f}")
print("Per-group one-factor fit:")
for lab, r in per_group.items():
    print(f"  {lab:6s} n={r['n']:3d} CFI {r['cfi']:.4f} RMSEA {r['rmsea']:.4f}")
print(f"Polychoric eigenvalues {evp[0]:.2f}, {evp[1]:.2f}, {evp[2]:.2f}; ratio {evp[0] / evp[1]:.1f}")
