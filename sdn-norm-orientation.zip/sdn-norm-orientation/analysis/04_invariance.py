"""Multi-group CFA measurement invariance across driving experience (Table 8)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
from scipy import stats

from sdn.data import load, save_json, ITEMS
from sdn.mgcfa import fit_mgcfa

df = load()
X = df[ITEMS].values.astype(float)
a5 = df.A5.values
SPLITS = {
    "two_group": (np.where(a5 <= 2, 0, 1), "<=3yr vs >3yr (confirmatory)"),
    "three_group": (np.select([a5 == 1, a5 <= 3], [0, 1], 2), "<1yr; 1-5yr; >5yr"),
    "five_group": (a5, "all five licence-tenure categories (exploratory)"),
}

out = {}
for key, (g, desc) in SPLITS.items():
    rows, prev = {}, None
    for model in ["configural", "metric", "scalar"]:
        r = fit_mgcfa(X, g, model)
        assert r["converged"], f"{key} {model} did not converge"
        if prev is not None:
            dchi, ddf = r["chi2"] - prev["chi2"], r["df"] - prev["df"]
            r.update(dchi2=dchi, ddf=ddf, p=float(stats.chi2.sf(dchi, ddf)),
                     dcfi=r["cfi"] - prev["cfi"], drmsea=r["rmsea"] - prev["rmsea"])
        rows[model] = r
        prev = r
    out[key] = dict(description=desc, group_n=rows["configural"]["n"], models=rows)
save_json("04_invariance", out)

for key, v in out.items():
    print(f"{key} ({v['description']}; n = {list(v['group_n'])})")
    for m, r in v["models"].items():
        tail = (f"  dchi2({r['ddf']}) = {r['dchi2']:.1f}, p = {r['p']:.3f}, dCFI = {r['dcfi']:+.3f}, "
                f"dRMSEA = {r['drmsea']:+.3f}") if "dchi2" in r else ""
        print(f"  {m:10s} chi2 {r['chi2']:7.1f} df {r['df']:4d} chi2/df {r['chi2_df']:.3f} "
              f"CFI {r['cfi']:.3f} RMSEA {r['rmsea']:.3f}{tail}")
