"""Figures 1-4. Requires the results of scripts 02, 03, 05, 07 and 08."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from sdn.data import load, load_json, RESULTS, FIGURES, ITEMS, B, C, D, EXPERIENCE_LABELS
from sdn.stats_utils import mean_offdiag_r

BLUE, ORANGE, AQUA, RED = "#2a78d6", "#eb6834", "#1baf7a", "#e34948"
INK, SEC, MUT, GRID, BASE, SURF = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#ffffff"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.edgecolor": BASE,
                     "axes.labelcolor": SEC, "axes.titlecolor": INK, "xtick.color": MUT, "ytick.color": MUT,
                     "text.color": INK, "axes.spines.top": False, "axes.spines.right": False,
                     "figure.facecolor": SURF, "axes.facecolor": SURF})
DPI = 440
FIGURES.mkdir(exist_ok=True)
COL = {**{i: BLUE for i in B}, **{i: ORANGE for i in C}, **{i: AQUA for i in D}}
df = load()
theta = pd.read_csv(RESULTS / "theta.csv").theta.values
items = pd.read_csv(RESULTS / "grm_items.csv")
b = items[["b1", "b2", "b3", "b4"]].values


# ----------------------------------------------------------------------------- Figure 1: Wright map
def figure1():
    order = np.argsort(b.mean(1))[::-1]
    fig, (axL, axR) = plt.subplots(1, 2, figsize=(5.42, 5.2), sharey=True,
                                   gridspec_kw={"width_ratios": [1, 2.6], "wspace": 0.06})
    bins = np.arange(-2.5, 1.15, 0.075)
    cnt, edges = np.histogram(theta, bins=bins)
    axL.barh((edges[:-1] + edges[1:]) / 2, cnt, height=0.068, color=BLUE, edgecolor=SURF, linewidth=0.3)
    axL.invert_xaxis()
    axL.set_xlabel("Persons (n)")
    axL.set_ylabel("Latent trait θ (logits)", color=INK)
    axL.set_title("Persons", fontsize=9, fontweight="bold", pad=8)
    axL.axhline(theta.mean(), color=RED, linestyle="--", linewidth=1.2)
    axL.text(cnt.max() * 0.97, theta.mean() + 0.05, f"M = {theta.mean():.2f}", fontsize=7.5, color=RED, ha="left")
    axL.set_ylim(-2.55, 1.15)
    axL.xaxis.grid(True, color=GRID, linewidth=0.6)
    axL.set_axisbelow(True)
    for x, j in enumerate(order):
        c = COL[ITEMS[j]]
        axR.plot([x, x], [b[j].min(), b[j].max()], color=c, linewidth=0.8, alpha=0.55, zorder=2)
        axR.scatter([x] * 4, b[j], s=13, color=c, zorder=3)
    axR.axhline(theta.mean(), color=RED, linestyle="--", linewidth=1.2, zorder=1)
    axR.axhline(b.mean(), color=MUT, linestyle=":", linewidth=1.1, zorder=1)
    axR.text(27.4, b.mean() - 0.13, f"threshold M = {b.mean():.2f}", fontsize=7.5, color=SEC, ha="right")
    axR.set_xticks(range(28))
    axR.set_xticklabels([ITEMS[j] for j in order], rotation=90, fontsize=6.5)
    axR.set_xlim(-0.8, 27.8)
    axR.set_title("Item thresholds (δ₁–δ₄ per item)", fontsize=9, fontweight="bold", pad=8)
    axR.yaxis.grid(True, color=GRID, linewidth=0.6)
    axR.set_axisbelow(True)
    axR.tick_params(axis="x", length=0)
    h = [Line2D([0], [0], marker="o", linestyle="", color=BLUE, label="Safe Behaviour", markersize=5),
         Line2D([0], [0], marker="o", linestyle="", color=ORANGE, label="Peer", markersize=5),
         Line2D([0], [0], marker="o", linestyle="", color=AQUA, label="Parental", markersize=5),
         Line2D([0], [0], linestyle="--", color=RED, label="Person mean"),
         Line2D([0], [0], linestyle=":", color=MUT, label="Threshold mean")]
    fig.legend(handles=h, loc="lower center", ncol=5, fontsize=6.8, frameon=False, bbox_to_anchor=(0.55, 0.005),
               columnspacing=1.1, handletextpad=0.4)
    fig.subplots_adjust(left=0.115, right=0.985, top=0.94, bottom=0.19)
    fig.savefig(FIGURES / "Figure1_WrightMap.png", dpi=DPI, facecolor=SURF)
    plt.close(fig)


# ----------------------------------------------------------------------------- Figure 2: resampling null
def figure2():
    rs = load_json("07_resampling")
    pg = load_json("02_structure_cfa")["per_group_one_factor"]
    obs = rs["observed"]["g5"]["cfi"]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.3, 2.5), gridspec_kw={"width_ratios": [1.12, 1], "wspace": 0.3})
    bins = np.arange(0.885, 1.0001, 0.005)
    a1.hist(np.minimum(rs["draws"]["g2"]["cfi"], 1.0), bins=bins, color=BLUE, alpha=0.85,
            edgecolor=SURF, linewidth=0.4, label="n = 64 from 1–3yr group")
    a1.hist(np.minimum(rs["draws"]["g3"]["cfi"], 1.0), bins=bins, color=ORANGE, alpha=0.6,
            edgecolor=SURF, linewidth=0.4, label="n = 64 from 3–5yr group")
    top = a1.get_ylim()[1] * 1.25
    a1.set_ylim(0, top)
    a1.axvline(0.95, color=INK, linestyle="--", linewidth=1.0)
    a1.text(0.9505, top * 0.62, ".95", fontsize=7, color=SEC)
    a1.axvline(obs, color=RED, linewidth=2.0)
    a1.text(obs + 0.001, top * 0.4, f"observed\n>10yr\n{obs:.3f}", fontsize=7, color=RED)
    a1.set_xlim(0.885, 1.0)
    a1.set_xlabel("CFI of 1-factor model at n = 64")
    a1.set_ylabel("Resamples")
    a1.set_title("A   CFI is deflated at n = 64", fontsize=9, fontweight="bold", loc="left")
    a1.legend(fontsize=6.5, frameon=False, loc="upper left")
    a1.yaxis.grid(True, color=GRID, linewidth=0.6)
    a1.set_axisbelow(True)

    null = rs["sub_1_3yr"]
    labs = list(EXPERIENCE_LABELS.values())
    a2.axhspan(null["p05"], null["p95"], color="#e9e8e4", zorder=0)
    a2.text(0.1, null["p05"] + 0.004, "90% interval of the n = 64 null", fontsize=6.8, color=SEC)
    a2.axhline(0.95, color=INK, linestyle="--", linewidth=1.0)
    cfis = [pg[l]["cfi"] for l in labs]
    ns = [pg[l]["n"] for l in labs]
    a2.scatter(range(5), cfis, s=45, color=[BLUE] * 4 + [RED], zorder=3)
    for i, (c, n) in enumerate(zip(cfis, ns)):
        a2.text(i, c + 0.006, f"{c:.3f}", ha="center", fontsize=7.2, fontweight="bold")
        a2.text(i, 0.869, f"n={n}", ha="center", fontsize=6.3, color=MUT)
    a2.set_xticks(range(5))
    a2.set_xticklabels([l.replace("-", "–") for l in labs], fontsize=6.8)
    a2.set_xlim(-0.35, 4.2)
    a2.set_ylim(0.863, 1.022)
    a2.set_yticks([0.88, 0.92, 0.96, 1.00])
    a2.set_ylabel("CFI (1-factor model)")
    a2.set_title("B   Per-group fit vs the null band", fontsize=9, fontweight="bold", loc="left")
    a2.yaxis.grid(True, color=GRID, linewidth=0.6)
    a2.set_axisbelow(True)
    fig.subplots_adjust(left=0.075, right=0.99, top=0.9, bottom=0.18)
    fig.savefig(FIGURES / "Figure2_Resampling.png", dpi=DPI, facecolor=SURF)
    plt.close(fig)


# ----------------------------------------------------------------------------- Figure 3: DIF effect sizes
def figure3():
    get = lambda f: pd.read_csv(RESULTS / f).set_index("item").loc[ITEMS, "dR2"].values
    exp, gen, age = get("dif_A5_factor.csv"), get("dif_E1_linear.csv"), get("dif_E4_factor.csv")
    x, w = np.arange(28), 0.27
    fig, ax = plt.subplots(figsize=(6.3, 2.75))
    ax.bar(x - w, exp, w, color=BLUE, label="Driving experience")
    ax.bar(x, gen, w, color=ORANGE, label="Gender")
    ax.bar(x + w, age, w, color=AQUA, label="Age group")
    ax.axhline(0.035, color=RED, linestyle="--", linewidth=1.4)
    ax.text(0.2, 0.0322, "Zumbo (1999) negligible/moderate boundary (ΔR² = .035)", fontsize=6.5, color=RED, va="top")
    j = int(np.argmax(exp))
    ax.annotate(f"{ITEMS[j]}, largest observed\nΔR² = {exp[j]:.3f}".replace("0.", "."), xy=(j - w, exp[j]),
                xytext=(j + 2.0, 0.020), fontsize=6.8, color=SEC,
                arrowprops=dict(arrowstyle="-|>", color=MUT, lw=0.9, shrinkA=2, shrinkB=2))
    ax.set_xticks(x)
    ax.set_xticklabels(ITEMS, rotation=90, fontsize=6)
    ax.set_ylabel("Total DIF effect size (ΔR²)")
    ax.set_ylim(0, 0.040)
    ax.set_xlim(-0.8, 27.8)
    ax.yaxis.grid(True, color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)
    ax.legend(fontsize=6.5, frameon=False, loc="upper right", ncol=3, columnspacing=1.0)
    fig.subplots_adjust(left=0.105, right=0.99, top=0.97, bottom=0.17)
    fig.savefig(FIGURES / "Figure3_DIF.png", dpi=DPI, facecolor=SURF)
    plt.close(fig)


# ----------------------------------------------------------------------------- Figure 4: bimodality
def figure4():
    X = df[ITEMS].values.astype(float)
    m = X.mean(1)
    hi = pd.read_csv(RESULTS / "modes.csv").high_mode.values.astype(bool)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.3, 2.75), gridspec_kw={"width_ratios": [1.15, 1], "wspace": 0.35})
    a1.axvspan(2.5, 4.0, color="#fbeee9", ec="#f6d5c9", zorder=0)
    a1.hist(m, bins=np.arange(1, 5.01, 0.1), color=BLUE, edgecolor=SURF, linewidth=0.5, zorder=2)
    n_mid = int(((m >= 2.5) & (m < 4.0)).sum())
    a1.text(1.75, 200, f"{100 * (~hi).mean():.1f}%", ha="center", fontsize=7.5, color=SEC)
    a1.text(4.3, 225, f"{100 * hi.mean():.1f}%", ha="center", fontsize=7.5, color=SEC)
    a1.annotate(f"{n_mid} of {len(m):,}\nin [2.5, 4.0)", xy=(3.25, 25), xytext=(3.2, 200), ha="center",
                fontsize=7.5, color=SEC, arrowprops=dict(arrowstyle="-|>", color=MUT, lw=0.9))
    a1.set_xlim(1, 5)
    a1.set_xlabel("Respondent mean across all 28 items")
    a1.set_ylabel("Respondents")
    a1.set_title("A   Bimodal responding", fontsize=9, fontweight="bold", loc="left")
    a1.yaxis.grid(True, color=GRID, linewidth=0.6)
    a1.set_axisbelow(True)
    vals = [mean_offdiag_r(X), mean_offdiag_r(X[hi]), mean_offdiag_r(X[~hi])]
    a2.bar(range(3), vals, color=[BLUE, ORANGE, AQUA], width=0.6)
    for i, v in enumerate(vals):
        a2.text(i, max(v, 0) + 0.02, f"{v:.3f}", ha="center", fontsize=7.5, fontweight="bold")
    a2.axhline(0, color=BASE, linewidth=0.8)
    a2.set_xticks(range(3))
    a2.set_xticklabels([f"Full sample\n(n = {len(m):,})", f"High mode\n(n = {hi.sum()})",
                        f"Low mode\n(n = {(~hi).sum()})"], fontsize=6.8)
    a2.set_ylabel("Mean inter-item correlation")
    a2.set_ylim(-0.06, 0.8)
    a2.set_title("B   Within-mode covariance", fontsize=9, fontweight="bold", loc="left")
    a2.yaxis.grid(True, color=GRID, linewidth=0.6)
    a2.set_axisbelow(True)
    fig.subplots_adjust(left=0.085, right=0.99, top=0.9, bottom=0.2)
    fig.savefig(FIGURES / "Figure4_Bimodality.png", dpi=DPI, facecolor=SURF)
    plt.close(fig)


if __name__ == "__main__":
    for f in (figure1, figure2, figure3, figure4):
        f()
        print("wrote", f.__name__)
