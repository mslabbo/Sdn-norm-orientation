"""The bimodal response distribution (Section 4.11, Table 12, Figure 4).

Two-component Gaussian mixture on respondents' 28-item mean scores defines the response modes;
item statistics are recomputed within each mode; mode membership is cross-tabulated against
experience, gender and age. Writes results/modes.csv (mode membership used downstream)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.mixture import GaussianMixture

from sdn.data import load, save_json, RESULTS, ITEMS, EXPERIENCE_LABELS
from sdn.stats_utils import cronbach_alpha, pca_eigen, mean_offdiag_r

df = load()
X = df[ITEMS].values.astype(float)
m = X.mean(1).reshape(-1, 1)
theta = pd.read_csv(RESULTS / "theta.csv").theta.values

gm = GaussianMixture(2, random_state=0, n_init=20).fit(m)
g1 = GaussianMixture(1, random_state=0).fit(m)
hi_comp = int(np.argmax(gm.means_[:, 0]))
hi = gm.predict(m) == hi_comp
pd.DataFrame(dict(high_mode=hi.astype(int))).to_csv(RESULTS / "modes.csv", index=False)

mix = dict(pct_high=100 * hi.mean(), n_high=int(hi.sum()), n_low=int((~hi).sum()),
           mean_high=m[hi].mean(), sd_high=m[hi].std(ddof=1), mean_low=m[~hi].mean(), sd_low=m[~hi].std(ddof=1),
           bic_1=g1.bic(m), bic_2=gm.bic(m), bic_margin=g1.bic(m) - gm.bic(m),
           n_between_2_5_and_4=int(((m >= 2.5) & (m < 4.0)).sum()),
           max_low=m[~hi].max(), min_high=m[hi].min())

# Same structure in the EAP estimates
gt = GaussianMixture(2, random_state=0, n_init=10).fit(theta.reshape(-1, 1))
mu = np.sort(gt.means_[:, 0])
post = gt.predict_proba(theta.reshape(-1, 1))
theta_mix = dict(component_means=mu,
                 max_theta_low_mode=theta[~hi].max(), min_theta_high_mode=theta[hi].min(),
                 n_theta_in_gap=int(((theta > theta[~hi].max()) & (theta < theta[hi].min())).sum()),
                 pct_theta_between_m1_5_and_0=100 * np.mean((theta > -1.5) & (theta < 0)),
                 pct_ambiguous_membership=100 * np.mean(post.max(1) < .99),
                 max_theta=theta.max(), max_theta_sd_above_mean=(theta.max() - theta.mean()) / theta.std())


def block(Xs):
    ev = pca_eigen(Xs)
    return dict(n=len(Xs), composite_mean=Xs.mean(), mean_r=mean_offdiag_r(Xs), alpha=cronbach_alpha(Xs),
                pc1_pct=100 * ev[0] / Xs.shape[1], pc1_pc2=ev[0] / ev[1])


table12 = dict(full=block(X), high=block(X[hi]), low=block(X[~hi]))

# Share of each item's variance between modes (eta squared) and per-item Cohen's d
eta2, d = [], []
for j in range(X.shape[1]):
    x = X[:, j]
    ss_b = hi.sum() * (x[hi].mean() - x.mean()) ** 2 + (~hi).sum() * (x[~hi].mean() - x.mean()) ** 2
    eta2.append(ss_b / ((x - x.mean()) ** 2).sum())
    sp = np.sqrt(((hi.sum() - 1) * x[hi].var(ddof=1) + ((~hi).sum() - 1) * x[~hi].var(ddof=1)) / (len(x) - 2))
    d.append((x[hi].mean() - x[~hi].mean()) / sp)

# Mode membership by experience, gender, age
assoc = {}
for var in ["A5", "E1", "E4"]:
    ct = pd.crosstab(df[var], np.where(hi, "high", "low"))
    chi2, p, dof, _ = stats.chi2_contingency(ct)
    assoc[var] = dict(chi2=chi2, df=dof, p=p, pct_low_by_level=(100 * ct["low"] / ct.sum(axis=1)).round(1).to_dict())

out = dict(mixture=mix, theta_mixture=theta_mix, table12=table12, mean_eta2_pct=100 * np.mean(eta2),
           cohen_d=dict(min=min(d), max=max(d)), association=assoc)
save_json("08_bimodality", out)

print(f"Mixture: high {mix['pct_high']:.1f}% (n = {mix['n_high']}) M {mix['mean_high']:.2f} SD {mix['sd_high']:.2f}; "
      f"low n = {mix['n_low']} M {mix['mean_low']:.2f} SD {mix['sd_low']:.2f}; BIC margin {mix['bic_margin']:.0f}")
print(f"  between 2.5 and 4.0: {mix['n_between_2_5_and_4']}; max low {mix['max_low']:.2f}; min high {mix['min_high']:.2f}")
print(f"Theta mixture means {mu[0]:.2f}, {mu[1]:.2f}; highest low-mode theta {theta_mix['max_theta_low_mode']:.2f}, "
      f"lowest high-mode theta {theta_mix['min_theta_high_mode']:.2f} (n between: {theta_mix['n_theta_in_gap']}); "
      f"theta in (-1.5, 0): {theta_mix['pct_theta_between_m1_5_and_0']:.2f}%; "
      f"ambiguous membership: {theta_mix['pct_ambiguous_membership']:.1f}%"
      f"\n  "
      f"max theta {theta.max():.3f} = {theta_mix['max_theta_sd_above_mean']:.2f} SD above mean")
for k, r in table12.items():
    print(f"  {k:5s} n {r['n']:4d} mean {r['composite_mean']:.2f} r {r['mean_r']:.3f} alpha {r['alpha']:.2f} "
          f"PC1 {r['pc1_pct']:.1f}% ratio {r['pc1_pc2']:.2f}")
print(f"Between-mode share of item variance {100 * np.mean(eta2):.1f}%; Cohen's d {min(d):.2f}-{max(d):.2f}")
for var, r in assoc.items():
    print(f"  {var}: chi2({r['df']}) = {r['chi2']:.2f}, p = {r['p']:.3f}; % low: {r['pct_low_by_level']}")
