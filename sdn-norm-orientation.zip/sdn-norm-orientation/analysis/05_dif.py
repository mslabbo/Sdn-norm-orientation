"""Ordinal logistic regression DIF (Zumbo, 1999) across driving experience, gender and age (Table 9,
Figure 3, Section 4.8). Conditions on the EAP trait estimate from analysis/03_irt.py.

M1: item ~ theta;  M2: + group (uniform DIF);  M3: + theta x group (non-uniform DIF).
Effect size: change in Nagelkerke pseudo-R^2 from M1 to M3. Benjamini-Hochberg FDR across 28 items.
Experience (A5) and age (E4) are entered as factors and as ordered numeric codes; gender (E1) is binary.
"""
import sys
import warnings
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.miscmodels.ordinal_model import OrderedModel
from statsmodels.stats.multitest import multipletests

from sdn.data import load, save_json, RESULTS, ITEMS, SCALE, PERSONAL

warnings.filterwarnings("ignore")
df = load()
X = df[ITEMS].values.astype(int)
theta = pd.read_csv(RESULTS / "theta.csv").theta.values
N = len(X)


def ll_null(y):
    _, cnt = np.unique(y, return_counts=True)
    return float(np.sum(cnt * np.log(cnt / len(y))))


def fit_ord(y, Z):
    return OrderedModel(y, Z, distr="logit").fit(method="bfgs", maxiter=2000, disp=0)


def nagelkerke(llm, ll0, n):
    return (1 - np.exp(2 * (ll0 - llm) / n)) / (1 - np.exp(2 * ll0 / n))


def design(gvar, as_factor):
    g = df[gvar].values.astype(float)
    if as_factor:
        lev = np.unique(g)
        return np.column_stack([(g == l).astype(float) for l in lev[1:]])
    return g.reshape(-1, 1)


def dif(gvar, as_factor):
    G = design(gvar, as_factor)
    th = theta.reshape(-1, 1)
    rows = []
    for j, item in enumerate(ITEMS):
        y = X[:, j]
        l0 = ll_null(y)
        m1 = fit_ord(y, th)
        m2 = fit_ord(y, np.column_stack([th, G]))
        m3 = fit_ord(y, np.column_stack([th, G, G * th]))
        k = G.shape[1]
        lru, lrn, lrt = 2 * (m2.llf - m1.llf), 2 * (m3.llf - m2.llf), 2 * (m3.llf - m1.llf)
        rows.append(dict(item=item, scale=SCALE[item],
                         LR_unif=lru, p_unif=stats.chi2.sf(max(lru, 0), k),
                         LR_nonunif=lrn, p_nonunif=stats.chi2.sf(max(lrn, 0), k),
                         LR_total=lrt, p_total=stats.chi2.sf(max(lrt, 0), 2 * k),
                         dR2=nagelkerke(m3.llf, l0, N) - nagelkerke(m1.llf, l0, N),
                         group_coefs=list(np.asarray(m2.params)[1:1 + k])))
    t = pd.DataFrame(rows)
    for c in ["unif", "nonunif", "total"]:
        t[f"q_{c}"] = multipletests(t[f"p_{c}"].values, method="fdr_bh")[1]
    t["zumbo"] = np.where(t.dR2 < .035, "negligible", np.where(t.dR2 < .070, "moderate", "large"))
    return t


SPECS = [("A5", "factor"), ("A5", "linear"), ("E1", "linear"), ("E4", "factor"), ("E4", "linear")]
out, tables = {}, {}
for gvar, spec in SPECS:
    t = dif(gvar, spec == "factor")
    t.drop(columns="group_coefs").to_csv(RESULTS / f"dif_{gvar}_{spec}.csv", index=False)
    tables[(gvar, spec)] = t
    imin = t.p_total.idxmin()
    out[f"{gvar}_{spec}"] = dict(
        n_sig_total=int((t.q_total < .05).sum()),
        min_p_total=t.p_total.min(), min_p_item=t.item[imin], min_q_total=t.q_total.min(),
        min_q_unif=t.q_unif.min(), min_q_unif_item=t.item[t.q_unif.idxmin()],
        min_q_nonunif=t.q_nonunif.min(), min_q_nonunif_item=t.item[t.q_nonunif.idxmin()],
        max_dR2=t.dR2.max(), max_dR2_item=t.item[t.dR2.idxmax()],
        all_negligible=bool((t.zumbo == "negligible").all()),
        sig_unif=t.item[t.q_unif < .05].tolist(), sig_nonunif=t.item[t.q_nonunif < .05].tolist(),
        items={r.item: dict(p_unif=r.p_unif, q_unif=r.q_unif, p_nonunif=r.p_nonunif, q_nonunif=r.q_nonunif,
                            p_total=r.p_total, q_total=r.q_total, dR2=r.dR2) for r in t.itertuples()})

# Focal item B7 across experience (factor coding): uniform component and group coefficients
b7 = tables[("A5", "factor")].set_index("item").loc["B7"]
out["B7_experience_factor"] = dict(LR_unif=b7.LR_unif, p_unif=b7.p_unif, q_unif=b7.q_unif, dR2=b7.dR2,
                                   coefs_vs_lt1yr=dict(zip(["1-3yr", "3-5yr", "5-10yr", ">10yr"], b7.group_coefs)))

# Do personal-practice items show larger experience DIF than social-norm items? (Section 4.8)
t = tables[("A5", "factor")]
pers = t.dR2[t.item.isin(PERSONAL)].values
soc = t.dR2[~t.item.isin(PERSONAL)].values
mw = stats.mannwhitneyu(pers, soc, alternative="two-sided")
out["personal_vs_social"] = dict(mean_personal=pers.mean(), mean_social=soc.mean(), n_personal=len(pers),
                                 n_social=len(soc), U=float(mw.statistic), p=float(mw.pvalue),
                                 top5=t.sort_values("dR2", ascending=False).item.head(5).tolist())
out["max_dR2_overall"] = max(out[f"{g}_{s}"]["max_dR2"] for g, s in SPECS)
save_json("05_dif", out)

for gvar, spec in SPECS:
    r = out[f"{gvar}_{spec}"]
    print(f"{gvar} [{spec:6s}] sig total {r['n_sig_total']}/28 | min p {r['min_p_total']:.4f} ({r['min_p_item']}) "
          f"| min q {r['min_q_total']:.3f} | max dR2 {r['max_dR2']:.4f} ({r['max_dR2_item']}) | "
          f"q_unif min {r['min_q_unif']:.3f} ({r['min_q_unif_item']}) q_nonunif min {r['min_q_nonunif']:.3f} "
          f"({r['min_q_nonunif_item']})")
b = out["B7_experience_factor"]
print(f"B7 uniform (experience, factor): LR(4) = {b['LR_unif']:.2f}, p = {b['p_unif']:.4f}, q = {b['q_unif']:.3f}; "
      f"coefs {', '.join(f'{k} {v:+.2f}' for k, v in b['coefs_vs_lt1yr'].items())}")
pv = out["personal_vs_social"]
print(f"Personal vs social mean dR2: {pv['mean_personal']:.4f} vs {pv['mean_social']:.4f}, "
      f"U = {pv['U']:.0f}, p = {pv['p']:.3f}; top 5: {pv['top5']}")
