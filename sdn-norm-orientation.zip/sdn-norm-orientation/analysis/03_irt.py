"""Item response calibration: model comparison (Table 5 and IRT rows of Table 13), GRM item
parameters and fit (Table 6), local dependence (Q3), separation and targeting (Table 7).
Writes results/theta.csv (EAP estimates used by the DIF and bimodality analyses) and
results/grm_items.csv (full 28-item calibration)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from scipy import stats

from sdn.data import load, save_json, RESULTS, ITEMS, SCALE
from sdn import irt

df = load()
Xz = df[ITEMS].values.astype(int) - 1
N, P = Xz.shape

fits = {}
for name, kw in [("grm", dict(model="grm")),
                 ("gpcm", dict(model="gpcm")),
                 ("grm_eh", dict(model="grm", free_density=True, max_iter=500))]:
    fits[name] = irt.fit_em(Xz, **kw)
    f = fits[name]
    print(f"{name:7s} iterations {f['iterations']:3d}  -2LL {f['m2ll']:.1f}  k {f['npar']}  "
          f"AIC {f['aic']:.1f}  BIC {f['bic']:.1f}", flush=True)
grm = fits["grm"]
A, Bt = grm["a"], grm["b"]

# Person estimates (EAP, standard normal prior)
theta, se = irt.eap(grm, Xz)
RESULTS.mkdir(exist_ok=True)
pd.DataFrame(dict(theta=theta, se=se)).to_csv(RESULTS / "theta.csv", index=False)

# Item fit, local dependence
E, V = irt.expected_scores(grm, theta)
infit, outfit = irt.item_fit(Xz, E, V)
q3 = irt.q3(Xz, E)
items = pd.DataFrame(dict(item=ITEMS, scale=[SCALE[i] for i in ITEMS], a=A,
                          b1=Bt[:, 0], b2=Bt[:, 1], b3=Bt[:, 2], b4=Bt[:, 3],
                          infit=infit, outfit=outfit,
                          a_gpcm=fits["gpcm"]["a"], a_grm_eh=fits["grm_eh"]["a"]))
items.to_csv(RESULTS / "grm_items.csv", index=False)

# Separation, reliability and targeting
person = irt.separation(theta, se)
loc = Bt.mean(1)
item_info = (V.sum(0)) * A ** 2
item = irt.separation(loc, 1 / np.sqrt(item_info))
within = np.mean((theta >= Bt.min()) & (theta <= Bt.max()))

# Latent density of the empirical-histogram GRM: mass below the antimode between its two peaks
dens = fits["grm_eh"]["density"]
peaks = [i for i in range(1, len(dens) - 1) if dens[i] >= dens[i - 1] and dens[i] >= dens[i + 1]]
top2 = sorted(sorted(peaks, key=lambda i: dens[i])[-2:])
anti = top2[0] + int(np.argmin(dens[top2[0]:top2[1] + 1]))
eh_lower_mass = float(dens[:anti].sum())

rho = lambda x, y: float(stats.spearmanr(x, y)[0])
out = dict(
    models={k: {m: f[m] for m in ["m2ll", "npar", "aic", "bic", "iterations"]} for k, f in fits.items()},
    discrimination=dict(min=A.min(), max=A.max(), mean=A.mean()),
    theta=dict(mean=theta.mean(), sd=theta.std(), min=theta.min(), max=theta.max(), mean_se=se.mean()),
    mean_thresholds=Bt.mean(0), thresholds_ordered=bool((np.diff(Bt, axis=1) > 0).all()),
    threshold_ranges=[[Bt[:, k].min(), Bt[:, k].max()] for k in range(4)],
    infit=dict(min=infit.min(), max=infit.max(), mean=infit.mean()),
    outfit=dict(min=outfit.min(), max=outfit.max(), mean=outfit.mean()),
    q3=dict(min=q3.min(), max=q3.max(), mean=q3.mean(), n_pairs=len(q3),
            n_abs_gt_20=int((np.abs(q3) > .2).sum()), n_christensen=int((np.abs(q3 - q3.mean()) > .2).sum())),
    person=person, item=item,
    targeting=dict(person_mean=theta.mean(), threshold_mean=Bt.mean(), gap=theta.mean() - Bt.mean(),
                   pct_within_threshold_range=100 * within, max_threshold=Bt.max()),
    spearman=dict(grm_gpcm=rho(A, fits["gpcm"]["a"]), grm_eh=rho(A, fits["grm_eh"]["a"])),
    eh_density_lower_mode_mass=eh_lower_mass, eh_antimode_theta=float(irt.Q[anti]),
    eh_discrimination=dict(min=fits["grm_eh"]["a"].min(), max=fits["grm_eh"]["a"].max(),
                           mean=fits["grm_eh"]["a"].mean()),
)
save_json("03_irt", out)
np.save(RESULTS / "grm_eh_density.npy", dens)

print(f"GRM a {A.min():.3f}-{A.max():.3f} (M {A.mean():.3f}); theta M {theta.mean():.3f} SD {theta.std():.3f} "
      f"[{theta.min():.3f}, {theta.max():.3f}] mean SE {se.mean():.3f}")
print("Mean thresholds", np.round(Bt.mean(0), 3), "| all ordered:", out["thresholds_ordered"])
print(f"Infit {infit.min():.3f}-{infit.max():.3f} (M {infit.mean():.3f}); "
      f"outfit {outfit.min():.3f}-{outfit.max():.3f} (M {outfit.mean():.3f})")
print(f"Q3 {q3.min():.3f} to {q3.max():.3f} (M {q3.mean():.3f}); pairs flagged: {out['q3']['n_abs_gt_20']}, "
      f"{out['q3']['n_christensen']}")
print(f"Person separation {person['separation']:.2f} reliability {person['reliability']:.3f} "
      f"strata {person['strata']:.2f}; item separation {item['separation']:.2f} reliability {item['reliability']:.3f}")
print(f"Targeting: threshold M {Bt.mean():.3f}, gap {theta.mean() - Bt.mean():+.3f}, "
      f"within range {100 * within:.1f}%")
print(f"Spearman a: GRM-GPCM {out['spearman']['grm_gpcm']:.2f}, GRM-EH {out['spearman']['grm_eh']:.2f}; "
      f"EH lower-mode mass {100 * eh_lower_mass:.1f}%")
print("Table 6 (selected items):")
for it in ["D3", "D6", "D5", "D9", "C1", "D8", "C7", "D4", "D10", "B2", "C3", "B3", "D11", "C8", "B4"]:
    r = items.set_index("item").loc[it]
    print(f"  {it:4s} {r.a:.3f} {r.b1:+.2f} {r.b2:+.2f} {r.b3:+.2f} {r.b4:+.2f} {r.infit:.3f} {r.outfit:.3f}")
