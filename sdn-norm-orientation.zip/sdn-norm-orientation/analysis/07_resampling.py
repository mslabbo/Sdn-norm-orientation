"""Sample-size sensitivity of per-group CFA fit (Table 11, Figure 2, Section 4.10).

500 subsamples of n = 64 drawn without replacement from the 1-3yr group (n = 408) and from the
3-5yr group (n = 257); the one-factor model is re-estimated in each. The >10yr group (n = 64) is
additionally bootstrapped 300 times. Each draw uses its own seed, so results do not depend on the
number of worker processes. Runtime: roughly 3-5 minutes on two cores.
"""
import sys
from multiprocessing import Pool
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from sdn.data import load, save_json, ITEMS
from sdn.cfa import fit_cfa

N_SUB, N_BOOT, SIZE = 500, 300, 64
df = load()
X = df[ITEMS].values.astype(float)
POOLS = {"g2": X[df.A5.values == 2], "g3": X[df.A5.values == 3], "g5": X[df.A5.values == 5]}


def job(args):
    pool, seed, boot = args
    Xp = POOLS[pool]
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(Xp), SIZE, replace=boot)
    r = fit_cfa(np.cov(Xp[idx].T), SIZE, [0] * 28, 1)
    return pool, seed, r["cfi"], r["rmsea"]


def summarise(cfi, rmsea, obs_cfi, obs_rmsea):
    cfi, rmsea = np.asarray(cfi), np.asarray(rmsea)
    return dict(n=len(cfi), mean=cfi.mean(), sd=cfi.std(ddof=1),
                p05=np.percentile(cfi, 5), p95=np.percentile(cfi, 95),
                pct_below_95=100 * np.mean(cfi < .95),
                pct_cfi_le_observed=100 * np.mean(cfi <= obs_cfi),
                pct_rmsea_ge_observed=100 * np.mean(rmsea >= obs_rmsea),
                # thresholds as printed in the originally submitted revision (N-divisor fit for >10yr)
                pct_cfi_le_0896=100 * np.mean(cfi <= 0.896),
                pct_rmsea_ge_0099=100 * np.mean(rmsea >= 0.099))


if __name__ == "__main__":
    obs = {k: fit_cfa(np.cov(v.T), len(v), [0] * 28, 1) for k, v in POOLS.items()}
    o_cfi, o_rmsea = obs["g5"]["cfi"], obs["g5"]["rmsea"]
    jobs = ([("g2", i, False) for i in range(N_SUB)] + [("g3", 10000 + i, False) for i in range(N_SUB)]
            + [("g5", 20000 + i, True) for i in range(N_BOOT)])
    with Pool() as p:
        res = p.map(job, jobs, chunksize=10)
    draws = {k: dict(cfi=[r[2] for r in res if r[0] == k], rmsea=[r[3] for r in res if r[0] == k]) for k in POOLS}
    out = dict(observed={k: dict(n=len(POOLS[k]), cfi=v["cfi"], rmsea=v["rmsea"]) for k, v in obs.items()},
               sub_1_3yr=summarise(draws["g2"]["cfi"], draws["g2"]["rmsea"], o_cfi, o_rmsea),
               sub_3_5yr=summarise(draws["g3"]["cfi"], draws["g3"]["rmsea"], o_cfi, o_rmsea),
               pooled=summarise(draws["g2"]["cfi"] + draws["g3"]["cfi"],
                                draws["g2"]["rmsea"] + draws["g3"]["rmsea"], o_cfi, o_rmsea),
               bootstrap_gt10yr=dict(mean=np.mean(draws["g5"]["cfi"]),
                                     ci95=np.percentile(draws["g5"]["cfi"], [2.5, 97.5])),
               draws=draws)
    save_json("07_resampling", out)

    print(f">10yr observed: CFI {o_cfi:.4f}, RMSEA {o_rmsea:.4f}")
    for k, lab in [("sub_1_3yr", "1-3yr"), ("sub_3_5yr", "3-5yr"), ("pooled", "pooled")]:
        s = out[k]
        print(f"  {lab:6s} M {s['mean']:.3f} (SD {s['sd']:.3f}) 5-95% {s['p05']:.3f}-{s['p95']:.3f} "
              f"below .95 {s['pct_below_95']:.1f}% | CFI <= observed {s['pct_cfi_le_observed']:.1f}% "
              f"RMSEA >= observed {s['pct_rmsea_ge_observed']:.1f}% | [<= .896: {s['pct_cfi_le_0896']:.1f}%, "
              f">= .099: {s['pct_rmsea_ge_0099']:.1f}%]")
    b = out["bootstrap_gt10yr"]
    print(f"  bootstrap >10yr: M {b['mean']:.3f}, 95% CI [{b['ci95'][0]:.3f}, {b['ci95'][1]:.3f}]")
