"""Group mean comparisons across driving experience (Table 10, Section 4.9): Kruskal-Wallis omnibus
tests and Holm-corrected pairwise Mann-Whitney tests on subscale composites."""
import sys
from itertools import combinations
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scipy import stats

from sdn.data import load, save_json, B, C, D, EXPERIENCE_LABELS
from sdn.stats_utils import holm

df = load()
groups = sorted(EXPERIENCE_LABELS)
out = {}
for name, items in [("Safe Behaviour", B), ("Peer", C), ("Parental", D)]:
    comp = df[items].mean(axis=1)
    samples = [comp[df.A5 == g].values for g in groups]
    H, p = stats.kruskal(*samples)
    pairs = list(combinations(groups, 2))
    raw = [stats.mannwhitneyu(samples[a - 1], samples[b - 1], alternative="two-sided").pvalue for a, b in pairs]
    adj = holm(raw)
    pw = {f"{EXPERIENCE_LABELS[a]} vs {EXPERIENCE_LABELS[b]}": dict(p=p_, p_holm=q_)
          for (a, b), p_, q_ in zip(pairs, raw, adj)}
    out[name] = dict(H=H, p=p, n_sig_holm=int((adj < .05).sum()), pairwise=pw,
                     focal=pw["1-3yr vs >10yr"])
save_json("06_group_means", out)

for name, r in out.items():
    smallest = sorted(r["pairwise"].items(), key=lambda kv: kv[1]["p"])[:2]
    print(f"{name:15s} H = {r['H']:.3f}, p = {r['p']:.3f}; significant after Holm: {r['n_sig_holm']}/10; "
          f"1-3yr vs >10yr raw p = {r['focal']['p']:.4f}, Holm p = {r['focal']['p_holm']:.3f}; smallest: "
          + "; ".join(f"{k} p = {v['p']:.3f} (Holm {v['p_holm']:.3f})" for k, v in smallest))
