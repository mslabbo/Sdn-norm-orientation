"""Sensitivity to the latent distribution (Table 13, Sections 3.9 and 4.12).

Latent class models (2 and 3 classes) are compared with the IRT models fitted in 03_irt.py on the
same marginal likelihood. The invariance question is re-examined without normality assumptions:
(i) a multi-group two-class model with class-conditional profiles equal vs free across the two-group
experience split; (ii) Mann-Whitney tests of every item within the high-endorsement mode.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd
from scipy import stats

from sdn.data import load, load_json, save_json, RESULTS, ITEMS
from sdn.lca import fit_lca, ll_fixed_profiles

df = load()
Xz = df[ITEMS].values.astype(int) - 1
N = len(Xz)
hi = pd.read_csv(RESULTS / "modes.csv").high_mode.values.astype(bool)
g_lo = df.A5.values <= 2                      # two-group split: <=3yr vs >3yr

rng = np.random.default_rng(7)
lca2 = fit_lca(Xz, 2, rng, n_start=6)
lca3 = fit_lca(Xz, 3, rng, n_start=6)
sub_lo = fit_lca(Xz[g_lo], 2, rng, n_start=4)
sub_hi = fit_lca(Xz[~g_lo], 2, rng, n_start=4)

# Agreement of the two-class assignment with the response-mode split (08_bimodality.py)
cls = lca2["post"].argmax(1)
high_class = int(np.argmax([Xz[cls == c].mean() for c in range(2)]))
agreement = np.mean((cls == high_class) == hi)
sizes3 = np.sort(lca3["pi"])

# Multi-group two-class model: profiles shared (class sizes free per group) vs fully free
ll_shared = sum(ll_fixed_profiles(Xz[m], lca2["profiles"])[0] for m in [g_lo, ~g_lo])
ll_free = sub_lo["ll"] + sub_hi["ll"]
lr = 2 * (ll_free - ll_shared)
ddf = 2 * lca2["npar"] - (lca2["npar"] - 1 + 2)            # 450 free - 226 shared = 224
mg = dict(ll_shared=ll_shared, ll_free=ll_free, chi2=lr, df=ddf, p=float(stats.chi2.sf(lr, ddf)),
          bic_favours_equality_by=ddf * np.log(N) - lr)

# Item-level comparison within the high-endorsement mode
p = np.array([stats.mannwhitneyu(Xz[hi & g_lo, j], Xz[hi & ~g_lo, j], alternative="two-sided").pvalue
              for j in range(len(ITEMS))])
q = stats.false_discovery_control(p)
within = dict(n_low_exp=int((hi & g_lo).sum()), n_high_exp=int((hi & ~g_lo).sum()),
              min_p=p.min(), min_q=q.min(), n_sig=int((q < .05).sum()))

irt = load_json("03_irt")["models"]
table13 = {"GRM, normal latent density": irt["grm"],
           "GPCM, normal latent density": irt["gpcm"],
           "GRM, empirical-histogram latent density": irt["grm_eh"],
           "Latent class model, 2 classes": {k: lca2[k] for k in ["m2ll", "npar", "aic", "bic"]},
           "Latent class model, 3 classes": {k: lca3[k] for k in ["m2ll", "npar", "aic", "bic"]}}
out = dict(table13=table13, lca2_agreement_with_modes_pct=100 * agreement, lca2_sizes=np.sort(lca2["pi"]),
           lca3_sizes=sizes3, lca3_smallest_class_pct=100 * sizes3[0], multigroup_lca=mg,
           within_high_mode=within)
save_json("09_latent_sensitivity", out)

print("Table 13")
for k, r in table13.items():
    print(f"  {k:42s} -2LL {r['m2ll']:9.1f}  k {r['npar']:3d}  AIC {r['aic']:9.1f}  BIC {r['bic']:9.1f}")
print(f"2-class agreement with response modes: {100 * agreement:.1f}%; 3-class sizes: {np.round(100 * sizes3, 1)}")
print(f"Multi-group LCA: chi2({ddf}) = {lr:.1f}, p = {mg['p']:.3f}; BIC favours equality by "
      f"{mg['bic_favours_equality_by']:.1f}")
print(f"Within high mode (n = {within['n_low_exp']} vs {within['n_high_exp']}): min q = {within['min_q']:.2f}")
