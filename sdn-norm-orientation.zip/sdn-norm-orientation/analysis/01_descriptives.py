"""Sample description (Table 1), norm-type classification (Table 2), category use, covariates."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd

from sdn.data import load, save_json, ITEMS, B, C, D, DESCRIPTIVE, INJUNCTIVE, PERSONAL, EXPERIENCE_LABELS

df = load()
N = len(df)


def pct_table(col, labels):
    vc = df[col].value_counts().sort_index()
    return {labels[k]: dict(n=int(v), pct=round(100 * v / N, 1)) for k, v in vc.items()}


# Codebook (Jin et al., 2023): E1 gender, E2 education, E3 monthly income, E4 age, A5 licence tenure.
table1 = dict(
    gender=pct_table("E1", {1: "Male", 2: "Female"}),
    age=pct_table("E4", {1: "18-25", 2: "25-30", 3: "30-40", 4: "40-50", 5: "50+"}),
    education=pct_table("E2", {1: "Middle school or below", 2: "High school", 3: "Undergraduate",
                               4: "Master's", 5: "Doctoral"}),
    income=pct_table("E3", {1: "<3,000", 2: "3-9k", 3: "9-15k", 4: "15-30k", 5: ">30k"}),
    licence_tenure=pct_table("A5", EXPERIENCE_LABELS),
    missing_cells=int(df[ITEMS].isna().sum().sum()),
    n_observations=int(N * len(ITEMS)),
)
table1["pct_undergraduate_or_above"] = round(100 * (df.E2 >= 3).mean(), 1)
table1["pct_age_25_to_50"] = round(100 * df.E4.isin([2, 3, 4]).mean(), 1)

# Category use across all 28 x 1,039 responses (Section 3.2).
vals = df[ITEMS].values.ravel()
category_pct = [round(float(100 * np.mean(vals == k)), 1) for k in range(1, 6)]

# Norm-type composites (Table 2, Section 3.3).
comp = {name: df[items].mean(axis=1) for name, items in
        [("descriptive", DESCRIPTIVE), ("injunctive", INJUNCTIVE), ("personal", PERSONAL)]}
table2 = {name: dict(n_items=len(items), mean=round(float(comp[name].mean()), 2)) for name, items in
          [("descriptive", DESCRIPTIVE), ("injunctive", INJUNCTIVE), ("personal", PERSONAL)]}
r_desc_inj = float(np.corrcoef(comp["descriptive"], comp["injunctive"])[0, 1])

# Covariates A3 (driving confidence) and A4 (consequence concern) against subscale composites.
subs = {"B": df[B].mean(axis=1), "C": df[C].mean(axis=1), "D": df[D].mean(axis=1)}
cov_r = {f"{a}-{s}": float(np.corrcoef(df[a], subs[s])[0, 1]) for a in ["A3", "A4"] for s in subs}

out = dict(table1=table1, category_pct=category_pct, table2=table2,
           r_descriptive_injunctive=r_desc_inj, covariate_r=cov_r,
           covariate_max_abs_r=max(abs(v) for v in cov_r.values()))
save_json("01_descriptives", out)

print("Table 1")
for k in ["gender", "age", "education", "income", "licence_tenure"]:
    print(f"  {k:15s}", "; ".join(f"{lab} {v['pct']}% (n={v['n']})" for lab, v in table1[k].items()))
print(f"  missing cells: {table1['missing_cells']} of {table1['n_observations']}")
print("Category use (%):", category_pct)
print("Table 2 means:", {k: v["mean"] for k, v in table2.items()}, f"| r(desc, inj) = {r_desc_inj:.3f}")
print(f"Covariates: max |r| = {out['covariate_max_abs_r']:.3f}")
