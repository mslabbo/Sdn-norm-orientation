"""Single-group maximum likelihood confirmatory factor analysis (covariance structure).

Normal-theory ML discrepancy:  F = log|Sigma| + tr(S Sigma^-1) - log|S| - p,
chi2 = (N - 1) F,  df = p(p+1)/2 - q.  CFI and TLI are computed against the
independence model; RMSEA = sqrt(max(chi2 - df, 0) / (df (N - 1))).
Factor variances are fixed to 1; all loadings are free.
"""
import numpy as np
from scipy.optimize import minimize


def _sigma(params, p, blocks, nfac):
    lam = params[:p]
    if nfac == 1:
        Phi = np.array([[1.0]])
        L = lam.reshape(p, 1)
    else:
        L = np.zeros((p, nfac))
        for i, f in enumerate(blocks):
            L[i, f] = lam[i]
        ncov = nfac * (nfac - 1) // 2
        cov = params[p:p + ncov]
        Phi = np.eye(nfac)
        k = 0
        for a in range(nfac):
            for b in range(a + 1, nfac):
                Phi[a, b] = Phi[b, a] = cov[k]
                k += 1
    theta = params[-p:]
    return L @ Phi @ L.T + np.diag(theta), L, Phi


def fit_cfa(S, N, blocks, nfac):
    """Fit a CFA to covariance matrix S (divisor N - 1). blocks: factor index per item."""
    p = S.shape[0]
    sd = np.sqrt(np.diag(S))
    lam0 = 0.7 * sd
    th0 = 0.51 * np.diag(S)
    ncov = nfac * (nfac - 1) // 2
    x0 = np.concatenate([lam0, np.full(ncov, 0.9), th0]) if nfac > 1 else np.concatenate([lam0, th0])
    logdetS = np.linalg.slogdet(S)[1]

    def F(x):
        Sig, _, Phi = _sigma(x, p, blocks, nfac)
        if nfac > 1 and (np.linalg.eigvalsh(Phi) <= 1e-8).any():
            return 1e6
        try:
            sign, logdet = np.linalg.slogdet(Sig)
            if sign <= 0:
                return 1e6
            val = logdet + np.trace(np.linalg.solve(Sig, S)) - logdetS - p
        except np.linalg.LinAlgError:
            return 1e6
        return val if np.isfinite(val) and val >= 0 else 1e6

    bounds = [(1e-4, None)] * p + [(-0.999, 0.999)] * ncov + [(1e-6, None)] * p
    if nfac > 1:
        x0[p:p + ncov] = np.clip(x0[p:p + ncov], -0.99, 0.99)
    res = minimize(F, x0, method="L-BFGS-B", bounds=bounds,
                   options=dict(maxiter=60000, maxfun=200000, ftol=1e-14, gtol=1e-10))

    q = 2 * p + ncov
    df = p * (p + 1) // 2 - q
    chi2 = (N - 1) * res.fun
    Sd = np.diag(np.diag(S))
    chi2b = (N - 1) * (np.linalg.slogdet(Sd)[1] + np.trace(np.linalg.solve(Sd, S)) - logdetS - p)
    dfb = p * (p + 1) // 2 - p
    d_m, d_b = max(chi2 - df, 0.0), max(chi2b - dfb, 0.0)
    cfi = 1 - d_m / d_b if d_b > 0 else np.nan
    tli = ((chi2b / dfb) - (chi2 / df)) / ((chi2b / dfb) - 1) if df > 0 else np.nan
    rmsea = np.sqrt(d_m / (df * (N - 1))) if df > 0 else np.nan
    Sig, L, Phi = _sigma(res.x, p, blocks, nfac)
    Ds = np.diag(1 / np.sqrt(np.diag(S)))
    Rres = Ds @ (S - Sig) @ Ds
    srmr = np.sqrt(np.mean(np.r_[Rres[np.tril_indices(p, -1)], np.diag(Rres)] ** 2))
    m2ll = N * (p * np.log(2 * np.pi) + np.linalg.slogdet(Sig)[1]
                + np.trace(np.linalg.solve(Sig, S * (N - 1) / N)))
    return dict(chi2=chi2, df=df, q=q, chi2_df=chi2 / df, cfi=cfi, tli=tli, rmsea=rmsea, srmr=srmr,
                aic=m2ll + 2 * q, bic=m2ll + np.log(N) * q, m2ll=m2ll,
                loadings=L, std_loadings=(L.sum(1) / np.sqrt(np.diag(S))), phi=Phi, N=N)
