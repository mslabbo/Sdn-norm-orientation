"""Unrestricted latent class models for polytomous items, estimated by EM with random starts.

Class-conditional response probabilities are floored at 1e-6 (and renormalised) after each M-step.
"""
import numpy as np

K = 5


def _onehot(Xz):
    return np.stack([(Xz == k) for k in range(K)], 2).astype(float)   # (N, P, K)


def _em(O, pi, th, tol=1e-6, max_iter=500, fix_profiles=False):
    last = None
    for _ in range(max_iter):
        logp = np.log(pi)[None, :] + np.einsum("npk,cpk->nc", O, np.log(np.clip(th, 1e-10, 1)))
        mx = logp.max(1, keepdims=True)
        lik = np.exp(logp - mx)
        ll = float((np.log(lik.sum(1)) + mx[:, 0]).sum())
        post = lik / lik.sum(1, keepdims=True)
        if last is not None and abs(ll - last) < tol:
            break
        last = ll
        pi = post.mean(0)
        if not fix_profiles:
            th = np.einsum("nc,npk->cpk", post, O) / post.sum(0)[:, None, None]
            th = np.clip(th, 1e-6, 1)                  # keep response probabilities off the boundary
            th /= th.sum(2, keepdims=True)
    return ll, pi, th, post


def fit_lca(Xz, C, rng, n_start=6, tol=1e-6, max_iter=500):
    """Best of n_start random starts. Starts perturb the marginal category proportions."""
    O = _onehot(Xz)
    base = O.mean(0)                                                   # (P, K)
    best = None
    for _ in range(n_start):
        th = np.clip(base[None] + rng.uniform(-.08, .08, (C,) + base.shape), .02, .98)
        th /= th.sum(2, keepdims=True)
        ll, pi, th, post = _em(O, np.full(C, 1 / C), th, tol, max_iter)
        if best is None or ll > best["ll"]:
            best = dict(ll=ll, pi=pi, profiles=th, post=post)
    N, P = Xz.shape
    npar = (C - 1) + C * P * (K - 1)
    best.update(C=C, m2ll=-2 * best["ll"], npar=npar,
                aic=-2 * best["ll"] + 2 * npar, bic=-2 * best["ll"] + np.log(N) * npar)
    return best


def ll_fixed_profiles(Xz, profiles, max_iter=300):
    """Log-likelihood with class-conditional profiles held fixed; only class sizes re-estimated."""
    C = profiles.shape[0]
    ll, pi, _, _ = _em(_onehot(Xz), np.full(C, 1 / C), profiles, tol=0, max_iter=max_iter,
                       fix_profiles=True)
    return ll, pi
