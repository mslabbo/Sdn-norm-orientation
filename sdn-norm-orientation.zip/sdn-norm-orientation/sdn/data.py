"""Data loading, item definitions, and result I/O shared by all analysis scripts."""
from pathlib import Path
import hashlib
import json
import warnings

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "Agressive_Driving_Data.csv"
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"

# SHA-256 of the CSV analysed in the paper (as distributed, with UTF-8 BOM).
EXPECTED_SHA256 = "c9385e89d8b8808eced589856ac450f3720bb60ff63446e0b9a9624f86d775c6"

B = [f"B{i}" for i in range(1, 8)]    # Safe Behaviour
C = [f"C{i}" for i in range(1, 10)]   # Peer Influence
D = [f"D{i}" for i in range(1, 13)]   # Parental Influence
ITEMS = B + C + D
SCALE = {**{i: "Safe Behaviour" for i in B}, **{i: "Peer" for i in C}, **{i: "Parental" for i in D}}

# Norm-type classification (manuscript Table 2).
DESCRIPTIVE = ["C7", "C8", "D1", "D2", "D6", "D8", "D9", "D11"]
INJUNCTIVE = ["C1", "C2", "C3", "C4", "C5", "C6", "D3", "D4", "D5", "D7", "D10"]
PERSONAL = B + ["C9", "D12"]

EXPERIENCE_LABELS = {1: "<1yr", 2: "1-3yr", 3: "3-5yr", 4: "5-10yr", 5: ">10yr"}


def load(check=True):
    """Load the dataset and verify it matches the published codebook."""
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"{DATA_FILE} not found. Download the dataset from https://osf.io/stcj2/ "
            "(Jin et al., 2023) and save it under that name; see data/README.md.")
    if check:
        sha = hashlib.sha256(DATA_FILE.read_bytes()).hexdigest()
        if sha != EXPECTED_SHA256:
            warnings.warn("Data file checksum differs from the file analysed in the paper; "
                          "codebook checks below will confirm whether the content matches.")
    df = pd.read_csv(DATA_FILE, encoding="utf-8-sig")
    if check:
        assert df.shape == (1039, 37), f"unexpected shape {df.shape}"
        assert df[ITEMS].isna().sum().sum() == 0, "missing item responses"
        assert df.A5.value_counts().sort_index().tolist() == [185, 408, 257, 125, 64], "A5 counts differ"
        assert df[ITEMS].min().min() == 1 and df[ITEMS].max().max() == 5, "item range differs"
    return df


def _jsonable(o):
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return _jsonable(o.tolist())
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    return o


def save_json(name, obj):
    RESULTS.mkdir(exist_ok=True)
    path = RESULTS / f"{name}.json"
    path.write_text(json.dumps(_jsonable(obj), indent=1, ensure_ascii=False), encoding="utf-8")
    return path


def load_json(name):
    return json.loads((RESULTS / f"{name}.json").read_text(encoding="utf-8"))
