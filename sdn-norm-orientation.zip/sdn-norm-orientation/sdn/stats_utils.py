"""Small statistical helpers: reliability, HTMT, AVE, Holm adjustment, polychoric correlation."""
import numpy as np
from scipy import stats
from scipy.optimize import minimize_scalar


def cronbach_alpha(X):
    X = np.asarray(X, float)
    k = X.shape[1]
    return k / (k - 1) * (1 - X.var(0, ddof=1).sum() / X.sum(1).var(ddof=1))


def pca_eigen(X):
    """Eigenvalues of the item correlation matrix, descending."""
    return np.sort(np.linalg.eigvalsh(np.corrcoef(np.asarray(X, float).T)))[::-1]


def mean_offdiag_r(X):
    R = np.corrcoef(np.asarray(X, float).T)
    return R[np.triu_indices_from(R, 1)].mean()


def ave_first_component(X):
    """AVE from first-principal-component loadings of the subscale correlation matrix."""
    w, v = np.linalg.eigh(np.corrcoef(np.asarray(X, float).T))
    L = v[:, -1] * np.sqrt(w[-1])
    return np.mean(L ** 2)


def htmt(R, idx_a, idx_b):
    """Heterotrait-monotrait ratio (Henseler et al., 2015) from an item correlation matrix."""
    het = R[np.ix_(idx_a, idx_b)].mean()

    def mono(idx):
        sub = R[np.ix_(idx, idx)]
        return sub[np.triu_indices_from(sub, 1)].mean()
    return het / np.sqrt(mono(idx_a) * mono(idx_b))


def holm(p):
    """Holm step-down adjusted p-values."""
    p = np.asarray(p, float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    run = 0.0
    for r, i in enumerate(order):
        run = max(run, (m - r) * p[i])
        adj[i] = min(run, 1.0)
    return adj


def _thresholds(x, K=5):
    """Category thresholds on the standard normal scale, clipped to +/-8 for the outer bounds."""
    cum = np.cumsum(np.bincount(x, minlength=K)[:K])[:-1] / len(x)
    return np.concatenate([[-8.0], stats.norm.ppf(np.clip(cum, 1e-10, 1 - 1e-10)), [8.0]])


def polychoric(x, y, K=5):
    """Two-step ML polychoric correlation for integer variables coded 0..K-1
    (thresholds fixed at their marginal estimates, then rho maximised)."""
    tx, ty = _thresholds(x, K), _thresholds(y, K)
    n = np.zeros((K, K))
    np.add.at(n, (x, y), 1)
    pts = np.array([[a, b] for a in tx for b in ty])

    def nll(rho):
        F = stats.multivariate_normal(mean=[0, 0], cov=[[1, rho], [rho, 1]]).cdf(pts)
        F = F.reshape(K + 1, K + 1)
        p = F[1:, 1:] - F[:-1, 1:] - F[1:, :-1] + F[:-1, :-1]
        return -np.sum(n * np.log(np.clip(p, 1e-12, None)))
    return minimize_scalar(nll, bounds=(-0.999, 0.999), method="bounded", options=dict(xatol=5e-4)).x
