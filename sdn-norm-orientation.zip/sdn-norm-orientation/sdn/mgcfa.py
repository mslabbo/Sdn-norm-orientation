"""Multi-group one-factor CFA with a mean structure: configural, metric and scalar models.

Per group g:  Sigma_g = psi_g * lam_g lam_g' + diag(theta_g),   mu_g = nu_g + lam_g * alpha_g.
Fit function (normal-theory ML, pooled over groups):
    F = sum_g (n_g / N) [ log|Sigma_g| + tr(S_g Sigma_g^-1) - log|S_g| - P + (m_g - mu_g)' Sigma_g^-1 (m_g - mu_g) ]
with S_g the unbiased (divisor n_g - 1) covariance matrix and chi2 = (N - 1) F.

Identification
  configural : lam, nu, theta free in every group; psi_g = 1, alpha_g = 0.
  metric     : lam equal across groups; psi_1 = 1, psi_g free (g > 1); nu, theta free; alpha_g = 0.
  scalar     : lam and nu equal across groups; psi_1 = 1, alpha_1 = 0; psi_g, alpha_g free (g > 1).
CFI is computed against the independence model (free means and variances, zero covariances);
RMSEA = sqrt(max(chi2 - df, 0) / (df (N - 1))).
"""
import numpy as np
from scipy.optimize import minimize


class _Layout:
    """Maps a flat parameter vector onto per-group lam, nu, log-theta, log-psi, alpha."""

    def __init__(self, model, G, P):
        self.model, self.G, self.P = model, G, P
        idx, k = {}, 0

        def take(name, size):
            nonlocal k
            idx[name] = slice(k, k + size)
            k += size

        shared_lam = model in ("metric", "scalar")
        shared_nu = model == "scalar"
        if shared_lam:
            take("lam", P)
        if shared_nu:
            take("nu", P)
        for g in range(G):
            if not shared_lam:
                take(f"lam{g}", P)
            if not shared_nu:
                take(f"nu{g}", P)
            take(f"th{g}", P)
            if model in ("metric", "scalar") and g > 0:
                take(f"psi{g}", 1)
            if model == "scalar" and g > 0:
                take(f"al{g}", 1)
        self.idx, self.q = idx, k

    def key(self, name, g):
        if name == "lam" and "lam" in self.idx:
            return "lam"
        if name == "nu" and "nu" in self.idx:
            return "nu"
        return f"{name}{g}"


def fit_mgcfa(X, groups, model):
    """X: (N, P) raw item responses; groups: length-N array of group labels."""
    labels = list(np.unique(groups))
    G, (N, P) = len(labels), X.shape
    Xs = [X[groups == lab] for lab in labels]
    ns = np.array([len(x) for x in Xs], float)
    w = ns / N
    Ss = [np.cov(x.T) for x in Xs]
    ms = [x.mean(0) for x in Xs]
    logdetS = [np.linalg.slogdet(S)[1] for S in Ss]
    lay = _Layout(model, G, P)

    x0 = np.zeros(lay.q)
    Spool = sum(wi * S for wi, S in zip(w, Ss))
    for g in range(G):
        x0[lay.idx[lay.key("lam", g)]] = 0.7 * np.sqrt(np.diag(Spool))
        x0[lay.idx[lay.key("nu", g)]] = ms[0] if model == "scalar" else ms[g]
        x0[lay.idx[f"th{g}"]] = np.log(0.5 * np.diag(Ss[g]))

    def unpack(x, g):
        lam = x[lay.idx[lay.key("lam", g)]]
        nu = x[lay.idx[lay.key("nu", g)]]
        th = np.exp(x[lay.idx[f"th{g}"]])
        psi = np.exp(x[lay.idx[f"psi{g}"]][0]) if f"psi{g}" in lay.idx else 1.0
        al = x[lay.idx[f"al{g}"]][0] if f"al{g}" in lay.idx else 0.0
        return lam, nu, th, psi, al

    def f_and_grad(x):
        F, grad = 0.0, np.zeros_like(x)
        for g in range(G):
            lam, nu, th, psi, al = unpack(x, g)
            Sig = psi * np.outer(lam, lam) + np.diag(th)
            sign, logdet = np.linalg.slogdet(Sig)
            if sign <= 0:
                return 1e10, np.zeros_like(x)
            Si = np.linalg.inv(Sig)
            d = ms[g] - (nu + lam * al)
            Sid = Si @ d
            Fg = logdet + np.trace(Ss[g] @ Si) - logdetS[g] - P + d @ Sid
            F += w[g] * Fg
            A = Si - Si @ Ss[g] @ Si - np.outer(Sid, Sid)
            b = -2 * Sid                                   # dF/dmu
            grad[lay.idx[lay.key("lam", g)]] += w[g] * (2 * psi * (A @ lam) + al * b)
            grad[lay.idx[lay.key("nu", g)]] += w[g] * b
            grad[lay.idx[f"th{g}"]] += w[g] * np.diag(A) * th
            if f"psi{g}" in lay.idx:
                grad[lay.idx[f"psi{g}"]] += w[g] * (lam @ A @ lam) * psi
            if f"al{g}" in lay.idx:
                grad[lay.idx[f"al{g}"]] += w[g] * (lam @ b)
        return F, grad

    res = minimize(f_and_grad, x0, jac=True, method="L-BFGS-B",
                   options=dict(maxiter=20000, maxfun=50000, ftol=1e-15, gtol=1e-9))
    chi2 = (N - 1) * res.fun
    df = G * (P * (P + 1) // 2 + P) - lay.q
    Fb = sum(w[g] * (np.log(np.diag(Ss[g])).sum() - logdetS[g]) for g in range(G))
    chi2b, dfb = (N - 1) * Fb, G * (P * (P + 1) // 2 - P)
    cfi = 1 - max(chi2 - df, 0) / max(chi2b - dfb, 1e-9)
    rmsea = np.sqrt(max(chi2 - df, 0) / (df * (N - 1)))
    return dict(model=model, groups=[int(v) if np.isscalar(v) else v for v in labels], n=ns.astype(int).tolist(),
                chi2=chi2, df=df, q=lay.q, chi2_df=chi2 / df, cfi=float(np.clip(cfi, 0, 1)),
                rmsea=rmsea, converged=bool(res.success or np.abs(res.jac).max() < 1e-5), grad_norm=float(np.abs(res.jac).max()))
