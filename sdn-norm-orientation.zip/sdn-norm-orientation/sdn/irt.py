"""Polytomous item response models estimated by Bock-Aitkin marginal maximum likelihood (EM).

Models
  GRM  (Samejima, 1969): P(X >= k | q) = logistic(a (q - b_k)), b_1 < ... < b_4 (ordered by construction).
  GPCM (Muraki, 1992)  : P(X = k | q) proportional to exp(sum_{h<=k} a (q - b_h)).
Latent density on a fixed 61-node grid over [-4, 4]: standard normal, or an empirical histogram
re-estimated from the posterior after every M-step (Bock & Aitkin, 1981; Woods, 2007).
Person parameters are expected a posteriori (EAP) estimates under the standard normal prior.
"""
import numpy as np
from scipy import stats
from scipy.optimize import minimize

K = 5
Q = np.linspace(-4, 4, 61)
NORMAL_PRIOR = stats.norm.pdf(Q) / stats.norm.pdf(Q).sum()


# ----------------------------------------------------------------------------- response functions
def grm_probs(a, b, q):
    z = a * (q[:, None] - b[None, :])
    cum = 1 / (1 + np.exp(-z))
    full = np.hstack([np.ones((len(q), 1)), cum, np.zeros((len(q), 1))])
    return np.clip(full[:, :-1] - full[:, 1:], 1e-10, 1)


def gpcm_probs(a, b, q):
    z = np.hstack([np.zeros((len(q), 1)), np.cumsum(a * (q[:, None] - b[None, :]), axis=1)])
    z -= z.max(1, keepdims=True)
    e = np.exp(z)
    return np.clip(e / e.sum(1, keepdims=True), 1e-10, 1)


def _unpack_grm(v):
    return np.exp(v[0]), v[1] + np.concatenate([[0], np.cumsum(np.exp(v[2:]))])


def _unpack_gpcm(v):
    return np.exp(v[0]), v[1:]


MODELS = {
    "grm": (grm_probs, _unpack_grm, np.array([np.log(1.5), -2.0, 0.0, 0.0, 0.0])),
    "gpcm": (gpcm_probs, _unpack_gpcm, np.array([np.log(1.5), -2.0, -1.0, 0.0, 1.0])),
}


# ----------------------------------------------------------------------------- estimation
def fit_em(Xz, model="grm", free_density=False, max_iter=400, tol=5e-4):
    """Bock-Aitkin EM. Xz: (N, P) integer responses coded 0..4.

    Returns dict with a (P,), b (P, 4), log-likelihood, -2LL, number of parameters, iterations,
    and the (final) latent density weights on the quadrature grid.
    """
    probs, unpack, v0 = MODELS[model]
    N, P = Xz.shape
    NQ = len(Q)
    prior = NORMAL_PRIOR.copy()
    V = [v0.copy() for _ in range(P)]
    onehot = [np.stack([(Xz[:, j] == k) for k in range(K)], 1).astype(float) for j in range(P)]
    last = None
    for it in range(max_iter):
        Pm = np.stack([probs(*unpack(V[j]), Q) for j in range(P)])
        Lg = np.ones((N, NQ))
        for j in range(P):
            Lg *= Pm[j][:, Xz[:, j]].T
        Lw = Lg * prior[None, :]
        marg = Lw.sum(1)
        ll = np.log(np.maximum(marg, 1e-300)).sum()
        post = Lw / np.maximum(marg[:, None], 1e-300)
        if last is not None and abs(ll - last) < tol:
            last = ll
            break
        last = ll
        for j in range(P):
            R = post.T @ onehot[j]                     # expected counts (NQ, K)

            def nll(v, R=R):
                return -np.sum(R * np.log(probs(*unpack(v), Q)))
            V[j] = minimize(nll, V[j], method="L-BFGS-B", options=dict(maxiter=300)).x
        if free_density:
            prior = post.sum(0) / post.sum()
    A = np.array([unpack(v)[0] for v in V])
    B = np.array([unpack(v)[1] for v in V])
    npar = P * 5 + (NQ - 1 if free_density else 0)
    return dict(model=model, free_density=free_density, a=A, b=B, ll=last, m2ll=-2 * last,
                npar=npar, aic=-2 * last + 2 * npar, bic=-2 * last + np.log(N) * npar,
                iterations=it + 1, density=prior)


def category_probs(fit, q):
    probs = MODELS[fit["model"]][0]
    return np.stack([probs(fit["a"][j], fit["b"][j], q) for j in range(len(fit["a"]))])  # (P, len(q), K)


def eap(fit, Xz, prior=NORMAL_PRIOR):
    Pm = category_probs(fit, Q)
    logL = np.zeros((Xz.shape[0], len(Q)))
    for j in range(Xz.shape[1]):
        logL += np.log(Pm[j][:, Xz[:, j]].T)
    logL += np.log(prior)[None, :]
    logL -= logL.max(1, keepdims=True)
    po = np.exp(logL)
    po /= po.sum(1, keepdims=True)
    theta = po @ Q
    se = np.sqrt(((Q[None, :] - theta[:, None]) ** 2 * po).sum(1))
    return theta, se


# ----------------------------------------------------------------------------- diagnostics
def expected_scores(fit, theta):
    """Model-implied mean E and variance V of each response at each person's theta: (N, P)."""
    Pm = category_probs(fit, theta)              # (P, N, K)
    k = np.arange(K)
    E = (Pm * k).sum(2).T
    V = (Pm * (k[None, None, :] - E.T[:, :, None]) ** 2).sum(2).T
    return E, V


def item_fit(Xz, E, V):
    Z2 = (Xz - E) ** 2 / V
    outfit = Z2.mean(0)
    infit = (V * Z2).sum(0) / V.sum(0)
    return infit, outfit


def q3(Xz, E):
    R = np.corrcoef((Xz - E).T)
    iu = np.triu_indices(R.shape[0], 1)
    return R[iu]


def separation(estimates, se, ddof=1):
    """Separation index G, reliability, and strata H = (4G + 1)/3 (Wright & Masters, 1982)."""
    obs_var = np.var(estimates, ddof=ddof)
    err_var = np.mean(se ** 2)
    true_var = max(obs_var - err_var, 0)
    G = np.sqrt(true_var / err_var)
    return dict(separation=G, reliability=true_var / obs_var, strata=(4 * G + 1) / 3)
