"""Compare regenerated results with the values reported in the manuscript.

Each check rounds the regenerated value to the number of decimals printed in the manuscript and
requires an exact match. All CFA statistics, including the per-group fit of the >10yr group
(Section 4.10, Table 11, Figure 2), use the (N - 1) likelihood convention throughout. Run after run_all.py. Exit status is non-zero if any check fails.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from sdn.data import load_json

# (label, results file, key path, reported value, decimals, scale)
CHECKS = [
    # Section 3.2 / Table 1 / Table 2
    ("Category 1 use (%)", "01_descriptives", "category_pct.0", 8.1, 1, 1),
    ("Category 5 use (%)", "01_descriptives", "category_pct.4", 35.8, 1, 1),
    ("Female (%)", "01_descriptives", "table1.gender.Female.pct", 38.5, 1, 1),
    ("Undergraduate or above (%)", "01_descriptives", "table1.pct_undergraduate_or_above", 52.7, 1, 1),
    ("Descriptive norm mean", "01_descriptives", "table2.descriptive.mean", 3.79, 2, 1),
    ("Injunctive norm mean", "01_descriptives", "table2.injunctive.mean", 3.78, 2, 1),
    ("r descriptive-injunctive", "01_descriptives", "r_descriptive_injunctive", .950, 3, 1),
    # Table 3
    ("alpha B", "02_structure_cfa", "table3.B.alpha", .943, 3, 1),
    ("alpha C", "02_structure_cfa", "table3.C.alpha", .953, 3, 1),
    ("alpha D", "02_structure_cfa", "table3.D.alpha", .965, 3, 1),
    ("alpha all", "02_structure_cfa", "table3.All.alpha", .984, 3, 1),
    ("PC1 % all", "02_structure_cfa", "table3.All.pc1_pct", 70.4, 1, 1),
    ("PC1/PC2 all", "02_structure_cfa", "table3.All.pc1_pc2", 43.69, 2, 1),
    ("PC1/PC2 B", "02_structure_cfa", "table3.B.pc1_pc2", 15.89, 2, 1),
    ("sqrt AVE B", "02_structure_cfa", "table3.B.sqrt_ave", .863, 3, 1),
    ("sqrt AVE C", "02_structure_cfa", "table3.C.sqrt_ave", .852, 3, 1),
    ("sqrt AVE D", "02_structure_cfa", "table3.D.sqrt_ave", .851, 3, 1),
    ("r B-C", "02_structure_cfa", "subscale_r.B-C", .936, 3, 1),
    ("r C-D", "02_structure_cfa", "subscale_r.C-D", .956, 3, 1),
    ("HTMT B-C", "02_structure_cfa", "htmt.B-C", .988, 3, 1),
    ("HTMT C-D", "02_structure_cfa", "htmt.C-D", .997, 3, 1),
    ("Polychoric eigenvalue 1", "02_structure_cfa", "polychoric_eigen.0", 18.45, 2, 1),
    ("Polychoric ratio", "02_structure_cfa", "polychoric_ratio", 33.5, 1, 1),
    # Table 4
    ("1F chi2", "02_structure_cfa", "table4.one_factor.chi2", 383.5, 1, 1),
    ("1F CFI", "02_structure_cfa", "table4.one_factor.cfi", .999, 3, 1),
    ("1F RMSEA", "02_structure_cfa", "table4.one_factor.rmsea", .010, 3, 1),
    ("1F AIC", "02_structure_cfa", "table4.one_factor.aic", 65710.4, 1, 1),
    ("1F BIC", "02_structure_cfa", "table4.one_factor.bic", 65987.4, 1, 1),
    ("3F chi2", "02_structure_cfa", "table4.three_factor.chi2", 354.6, 1, 1),
    ("3F AIC", "02_structure_cfa", "table4.three_factor.aic", 65687.5, 1, 1),
    ("3F BIC", "02_structure_cfa", "table4.three_factor.bic", 65979.4, 1, 1),
    ("3F phi C-D", "02_structure_cfa", "table4.three_factor.phi.C-D", .997, 3, 1),
    ("Delta chi2 (3)", "02_structure_cfa", "table4.lr_test.dchi2", 28.9, 1, 1),
    ("Loading min", "02_structure_cfa", "table4.one_factor.loadings_min", .819, 3, 1),
    ("Loading max", "02_structure_cfa", "table4.one_factor.loadings_max", .847, 3, 1),
    ("Loading mean", "02_structure_cfa", "table4.one_factor.loadings_mean", .833, 3, 1),
    # Section 4.3-4.6, Tables 5-7
    ("GRM -2LL", "03_irt", "models.grm.m2ll", 62431.0, 1, 1),
    ("GRM AIC", "03_irt", "models.grm.aic", 62711.0, 1, 1),
    ("GPCM AIC", "03_irt", "models.gpcm.aic", 62356.8, 1, 1),
    ("a min", "03_irt", "discrimination.min", 2.578, 3, 1),
    ("a max", "03_irt", "discrimination.max", 3.079, 3, 1),
    ("a mean", "03_irt", "discrimination.mean", 2.846, 3, 1),
    ("theta mean", "03_irt", "theta.mean", .006, 3, 1),
    ("theta SD", "03_irt", "theta.sd", .991, 3, 1),
    ("theta min", "03_irt", "theta.min", -2.294, 3, 1),
    ("theta max", "03_irt", "theta.max", .946, 3, 1),
    ("mean SE", "03_irt", "theta.mean_se", .127, 3, 1),
    ("Mean threshold 1", "03_irt", "mean_thresholds.0", -2.105, 3, 1),
    ("Mean threshold 4", "03_irt", "mean_thresholds.3", .579, 3, 1),
    ("Infit min", "03_irt", "infit.min", .931, 3, 1),
    ("Infit max", "03_irt", "infit.max", .954, 3, 1),
    ("Outfit max", "03_irt", "outfit.max", .963, 3, 1),
    ("Q3 min", "03_irt", "q3.min", -.124, 3, 1),
    ("Q3 max", "03_irt", "q3.max", .087, 3, 1),
    ("Q3 mean", "03_irt", "q3.mean", -.035, 3, 1),
    ("Person separation", "03_irt", "person.separation", 7.74, 2, 1),
    ("Person reliability", "03_irt", "person.reliability", .984, 3, 1),
    ("Person strata", "03_irt", "person.strata", 10.65, 2, 1),
    ("Item separation", "03_irt", "item.separation", 1.57, 2, 1),
    ("Item reliability", "03_irt", "item.reliability", .710, 3, 1),
    ("Threshold mean", "03_irt", "targeting.threshold_mean", -.743, 3, 1),
    ("Targeting gap", "03_irt", "targeting.gap", .749, 3, 1),
    ("Within threshold range (%)", "03_irt", "targeting.pct_within_threshold_range", 84.8, 1, 1),
    ("Spearman GRM-GPCM", "03_irt", "spearman.grm_gpcm", .92, 2, 1),
    ("Spearman GRM-EH", "03_irt", "spearman.grm_eh", .72, 2, 1),
    ("EH lower-mode mass (%)", "03_irt", "eh_density_lower_mode_mass", 20.3, 1, 100),
    # Table 8
    ("2G configural chi2", "04_invariance", "two_group.models.configural.chi2", 840.0, 1, 1),
    ("2G metric chi2", "04_invariance", "two_group.models.metric.chi2", 858.9, 1, 1),
    ("2G scalar chi2", "04_invariance", "two_group.models.scalar.chi2", 887.3, 1, 1),
    ("2G metric p", "04_invariance", "two_group.models.metric.p", .874, 3, 1),
    ("2G scalar p", "04_invariance", "two_group.models.scalar.p", .387, 3, 1),
    ("2G configural CFI", "04_invariance", "two_group.models.configural.cfi", .995, 3, 1),
    ("2G configural RMSEA", "04_invariance", "two_group.models.configural.rmsea", .014, 3, 1),
    ("3G configural chi2", "04_invariance", "three_group.models.configural.chi2", 1224.8, 1, 1),
    ("3G metric chi2", "04_invariance", "three_group.models.metric.chi2", 1273.1, 1, 1),
    ("3G scalar chi2", "04_invariance", "three_group.models.scalar.chi2", 1342.4, 1, 1),
    ("3G scalar p", "04_invariance", "three_group.models.scalar.p", .079, 3, 1),
    ("Per-group CFI 5-10yr", "02_structure_cfa", "per_group_one_factor.5-10yr.cfi", .988, 3, 1),
    ("5G configural chi2", "04_invariance", "five_group.models.configural.chi2", 2076.8, 1, 1),
    ("5G metric chi2", "04_invariance", "five_group.models.metric.chi2", 2182.1, 1, 1),
    ("5G scalar chi2", "04_invariance", "five_group.models.scalar.chi2", 2292.0, 1, 1),
    ("5G scalar p", "04_invariance", "five_group.models.scalar.p", .431, 3, 1),
    # Table 9 / Section 4.8
    ("DIF exp min p", "05_dif", "A5_factor.min_p_total", .0023, 4, 1),
    ("DIF exp min q", "05_dif", "A5_factor.min_q_total", .065, 3, 1),
    ("DIF exp max dR2", "05_dif", "A5_factor.max_dR2", .010, 3, 1),
    ("DIF gender min p", "05_dif", "E1_linear.min_p_total", .0818, 4, 1),
    ("DIF gender min q", "05_dif", "E1_linear.min_q_total", .997, 3, 1),
    ("DIF gender max dR2", "05_dif", "E1_linear.max_dR2", .002, 3, 1),
    ("DIF age min p", "05_dif", "E4_factor.min_p_total", .0109, 4, 1),
    ("DIF age min q", "05_dif", "E4_factor.min_q_total", .306, 3, 1),
    ("DIF age max dR2", "05_dif", "E4_factor.max_dR2", .008, 3, 1),
    ("B7 uniform LR(4)", "05_dif", "B7_experience_factor.LR_unif", 19.31, 2, 1),
    ("B7 uniform p", "05_dif", "B7_experience_factor.p_unif", .0007, 4, 1),
    ("B7 uniform q", "05_dif", "B7_experience_factor.q_unif", .019, 3, 1),
    ("B7 coef 1-3yr", "05_dif", "B7_experience_factor.coefs_vs_lt1yr.1-3yr", .44, 2, 1),
    ("B7 coef >10yr", "05_dif", "B7_experience_factor.coefs_vs_lt1yr.>10yr", -.54, 2, 1),
    ("B7 uniform q (ordered)", "05_dif", "A5_linear.items.B7.q_unif", .469, 3, 1),
    ("Min q uniform (ordered exp)", "05_dif", "A5_linear.min_q_unif", .232, 3, 1),
    ("B7 non-uniform q (age, ordered)", "05_dif", "E4_linear.items.B7.q_nonunif", .049, 3, 1),
    ("C4 non-uniform q (age, ordered)", "05_dif", "E4_linear.items.C4.q_nonunif", .049, 3, 1),
    ("B7 non-uniform q (age, factor)", "05_dif", "E4_factor.items.B7.q_nonunif", .269, 3, 1),
    ("Personal items mean dR2", "05_dif", "personal_vs_social.mean_personal", .0038, 4, 1),
    ("Social items mean dR2", "05_dif", "personal_vs_social.mean_social", .0032, 4, 1),
    ("Mann-Whitney U", "05_dif", "personal_vs_social.U", 94, 0, 1),
    ("Mann-Whitney p", "05_dif", "personal_vs_social.p", .694, 3, 1),
    # Table 10
    ("KW H Safe Behaviour", "06_group_means", "Safe Behaviour.H", 7.713, 3, 1),
    ("KW p Safe Behaviour", "06_group_means", "Safe Behaviour.p", .103, 3, 1),
    ("KW H Peer", "06_group_means", "Peer.H", 1.856, 3, 1),
    ("KW H Parental", "06_group_means", "Parental.H", 1.893, 3, 1),
    ("Focal raw p (B)", "06_group_means", "Safe Behaviour.focal.p", .0122, 4, 1),
    ("Focal Holm p (B)", "06_group_means", "Safe Behaviour.focal.p_holm", .110, 3, 1),
    ("Focal raw p (C)", "06_group_means", "Peer.focal.p", .5873, 4, 1),
    ("Focal raw p (D)", "06_group_means", "Parental.focal.p", .2688, 4, 1),
    # Table 11 / Section 4.10
    ("Null 1-3yr mean CFI", "07_resampling", "sub_1_3yr.mean", .957, 3, 1),
    ("Null 1-3yr SD", "07_resampling", "sub_1_3yr.sd", .019, 3, 1),
    ("Null 1-3yr 5th pct", "07_resampling", "sub_1_3yr.p05", .924, 3, 1),
    ("Null 1-3yr 95th pct", "07_resampling", "sub_1_3yr.p95", .983, 3, 1),
    ("Null 1-3yr % below .95", "07_resampling", "sub_1_3yr.pct_below_95", 31.4, 1, 1),
    ("Null 3-5yr mean CFI", "07_resampling", "sub_3_5yr.mean", .951, 3, 1),
    ("Null 3-5yr SD", "07_resampling", "sub_3_5yr.sd", .017, 3, 1),
    ("Null 3-5yr 5th pct", "07_resampling", "sub_3_5yr.p05", .921, 3, 1),
    ("Null 3-5yr 95th pct", "07_resampling", "sub_3_5yr.p95", .978, 3, 1),
    ("Null 3-5yr % below .95", "07_resampling", "sub_3_5yr.pct_below_95", 48.6, 1, 1),
    ("Full-sample CFI 1-3yr", "07_resampling", "observed.g2.cfi", 1.000, 3, 1),
    ("Full-sample CFI 3-5yr", "07_resampling", "observed.g3.cfi", .991, 3, 1),
    ("Bootstrap >10yr mean", "07_resampling", "bootstrap_gt10yr.mean", .720, 3, 1),
    ("Bootstrap >10yr 2.5%", "07_resampling", "bootstrap_gt10yr.ci95.0", .612, 3, 1),
    ("Bootstrap >10yr 97.5%", "07_resampling", "bootstrap_gt10yr.ci95.1", .808, 3, 1),
    (">10yr observed CFI", "07_resampling", "observed.g5.cfi", .899, 3, 1),
    (">10yr observed RMSEA", "07_resampling", "observed.g5.rmsea", .096, 3, 1),
    ("Null 1-3yr % CFI <= observed", "07_resampling", "sub_1_3yr.pct_cfi_le_observed", 1.0, 1, 1),
    ("Null 3-5yr % CFI <= observed", "07_resampling", "sub_3_5yr.pct_cfi_le_observed", 0.4, 1, 1),
    ("Null pooled % CFI <= observed", "07_resampling", "pooled.pct_cfi_le_observed", 0.7, 1, 1),
    ("Null pooled % RMSEA >= observed", "07_resampling", "pooled.pct_rmsea_ge_observed", 0.2, 1, 1),
    ("Null 1-3yr % RMSEA >= observed", "07_resampling", "sub_1_3yr.pct_rmsea_ge_observed", 0.0, 1, 1),
    ("Null 3-5yr % RMSEA >= observed", "07_resampling", "sub_3_5yr.pct_rmsea_ge_observed", 0.4, 1, 1),
    # Section 4.11 / Table 12
    ("High mode (%)", "08_bimodality", "mixture.pct_high", 79.7, 1, 1),
    ("High mode n", "08_bimodality", "mixture.n_high", 828, 0, 1),
    ("High mode mean", "08_bimodality", "mixture.mean_high", 4.31, 2, 1),
    ("High mode SD", "08_bimodality", "mixture.sd_high", .16, 2, 1),
    ("Low mode mean", "08_bimodality", "mixture.mean_low", 1.72, 2, 1),
    ("Low mode SD", "08_bimodality", "mixture.sd_low", .12, 2, 1),
    ("n with mean in [2.5, 4.0)", "08_bimodality", "mixture.n_between_2_5_and_4", 15, 0, 1),
    ("Highest low-mode mean", "08_bimodality", "mixture.max_low", 2.04, 2, 1),
    ("Lowest high-mode mean", "08_bimodality", "mixture.min_high", 3.14, 2, 1),
    ("Theta component low", "08_bimodality", "theta_mixture.component_means.0", -1.94, 2, 1),
    ("Theta component high", "08_bimodality", "theta_mixture.component_means.1", .50, 2, 1),
    ("Highest low-mode theta", "08_bimodality", "theta_mixture.max_theta_low_mode", -1.64, 2, 1),
    ("Lowest high-mode theta", "08_bimodality", "theta_mixture.min_theta_high_mode", -.57, 2, 1),
    ("Max theta SDs above mean", "08_bimodality", "theta_mixture.max_theta_sd_above_mean", .95, 2, 1),
    ("Mean r high mode", "08_bimodality", "table12.high.mean_r", .013, 3, 1),
    ("Mean r low mode", "08_bimodality", "table12.low.mean_r", -.002, 3, 1),
    ("Alpha high mode", "08_bimodality", "table12.high.alpha", .27, 2, 1),
    ("Alpha low mode", "08_bimodality", "table12.low.alpha", -.07, 2, 1),
    ("PC1 % high mode", "08_bimodality", "table12.high.pc1_pct", 6.0, 1, 1),
    ("PC1 % low mode", "08_bimodality", "table12.low.pc1_pct", 6.1, 1, 1),
    ("PC1/PC2 high mode", "08_bimodality", "table12.high.pc1_pc2", 1.24, 2, 1),
    ("PC1/PC2 low mode", "08_bimodality", "table12.low.pc1_pc2", 1.01, 2, 1),
    ("Between-mode variance (%)", "08_bimodality", "mean_eta2_pct", 69.0, 1, 1),
    ("Cohen's d min", "08_bimodality", "cohen_d.min", 3.44, 2, 1),
    ("Cohen's d max", "08_bimodality", "cohen_d.max", 3.93, 2, 1),
    ("Mode x experience chi2", "08_bimodality", "association.A5.chi2", 2.88, 2, 1),
    ("Mode x experience p", "08_bimodality", "association.A5.p", .579, 3, 1),
    ("Mode x gender p", "08_bimodality", "association.E1.p", .908, 3, 1),
    ("Mode x age chi2", "08_bimodality", "association.E4.chi2", 2.58, 2, 1),
    ("Mode x age p", "08_bimodality", "association.E4.p", .631, 3, 1),
    ("Low mode % in >10yr", "08_bimodality", "association.A5.pct_low_by_level.5", 26.6, 1, 1),
    # Table 13 / Section 4.12
    ("GPCM -2LL", "09_latent_sensitivity", "table13.GPCM, normal latent density.m2ll", 62076.8, 1, 1),
    ("GPCM BIC", "09_latent_sensitivity", "table13.GPCM, normal latent density.bic", 63049.3, 1, 1),
    ("EH-GRM -2LL", "09_latent_sensitivity", "table13.GRM, empirical-histogram latent density.m2ll", 59131.5, 1, 1),
    ("EH-GRM BIC", "09_latent_sensitivity", "table13.GRM, empirical-histogram latent density.bic", 60520.7, 1, 1),
    ("LCA2 -2LL", "09_latent_sensitivity", "table13.Latent class model, 2 classes.m2ll", 59141.5, 1, 1),
    ("LCA2 BIC", "09_latent_sensitivity", "table13.Latent class model, 2 classes.bic", 60704.4, 1, 1),
    ("LCA3 -2LL", "09_latent_sensitivity", "table13.Latent class model, 3 classes.m2ll", 58632.4, 1, 1),
    ("LCA3 BIC", "09_latent_sensitivity", "table13.Latent class model, 3 classes.bic", 60980.1, 1, 1),
    ("LCA2 agreement (%)", "09_latent_sensitivity", "lca2_agreement_with_modes_pct", 99.9, 1, 1),
    ("LCA3 smallest class (%)", "09_latent_sensitivity", "lca3_smallest_class_pct", 1.2, 1, 1),
    ("MG-LCA chi2(224)", "09_latent_sensitivity", "multigroup_lca.chi2", 227.1, 1, 1),
    ("MG-LCA p", "09_latent_sensitivity", "multigroup_lca.p", .429, 3, 1),
    ("MG-LCA BIC margin", "09_latent_sensitivity", "multigroup_lca.bic_favours_equality_by", 1328.8, 1, 1),
    ("Within-mode min q", "09_latent_sensitivity", "within_high_mode.min_q", .82, 2, 1),
]


def get(obj, path):
    for part in path.split("."):
        obj = obj[int(part)] if isinstance(obj, list) else obj[part]
    return obj


def main():
    cache, fails = {}, []
    for label, file, path, reported, dec, scale in CHECKS:
        res = cache.setdefault(file, load_json(file))
        # a key segment may itself contain dots (e.g. model names); resolve greedily
        try:
            val = get(res, path)
        except (KeyError, IndexError, ValueError):
            head, _, tail = path.partition(".")
            key = next(k for k in res[head] if tail.startswith(k + ".") or tail == k)
            val = get(res[head][key], tail[len(key) + 1:]) if tail != key else res[head][key]
        got = round(float(val) * scale, dec)
        ok = abs(got - reported) < 10 ** (-dec) / 2 + 1e-12
        print(f"{'OK  ' if ok else 'DIFF'} {label:34s} reported {reported:>10} regenerated {got:>10}   ({float(val) * scale:.6g})")
        if not ok:
            fails.append(label)
    print(f"\n{len(CHECKS) - len(fails)}/{len(CHECKS)} values match the manuscript.")
    if fails:
        print("Differences:", "; ".join(fails))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
